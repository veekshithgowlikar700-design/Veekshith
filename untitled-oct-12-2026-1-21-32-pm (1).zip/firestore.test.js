const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot create profile", async () => {
  const unauthedDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(
    unauthedDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice",
      coins: 500,
      rankPoints: 1000,
      rankTier: "Silver I",
      createdAt: new Date(),
    })
  );
});

test("Alice can create and read her own profile", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice",
      coins: 500,
      rankPoints: 1000,
      rankTier: "Silver I",
      createdAt: new Date(),
    })
  );

  const doc = await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).get());
  // Bob can also view Alice's profile (for leaderboard & match stats)
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertSucceeds(bobDb.collection("users").doc(ALICE_UID).get());
});

test("Bob cannot update Alice's profile", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await aliceDb.collection("users").doc(ALICE_UID).set({
    userId: ALICE_UID,
    displayName: "Alice",
    coins: 500,
    rankPoints: 1000,
    rankTier: "Silver I",
    createdAt: new Date(),
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).update({
      coins: 999999,
    })
  );
});

test("Alice can manage inventory item", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("inventory").doc("item1").set({
      userId: ALICE_UID,
      skinId: "ak47_asiimov",
      weaponName: "AK-47",
      skinName: "Asiimov",
      rarity: "Covert",
      wear: "Field-Tested",
      isStatTrak: true,
      killsCount: 0,
      acquiredAt: new Date(),
    })
  );

  // Bob cannot read Alice's private inventory
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("inventory").doc("item1").get()
  );
});

test("Alice can create matchmaking queue ticket", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("matchmaking_queue").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice",
      gameMode: "1v1",
      status: "waiting",
      rankPoints: 1000,
      createdAt: new Date(),
    })
  );
});

test("Alice can publish community map", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("community_maps").doc("map_dust3").set({
      creatorId: ALICE_UID,
      creatorName: "Alice",
      title: "Dust III",
      description: "Tactical remake of classic layout",
      gridData: "{\"tiles\":[]}",
      width: 20,
      height: 20,
      upvotes: 0,
      playsCount: 0,
      createdAt: new Date(),
    })
  );
});
