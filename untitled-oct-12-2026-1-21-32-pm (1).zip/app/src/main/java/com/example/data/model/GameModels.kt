package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class UserProfile(
    val userId: String = "",
    val displayName: String = "",
    val email: String = "",
    val photoUrl: String = "",
    val coins: Long = 500L,
    val rankPoints: Long = 1000L,
    val rankTier: String = "Silver I",
    val kills: Long = 0L,
    val deaths: Long = 0L,
    val headshots: Long = 0L,
    val wins: Long = 0L,
    val losses: Long = 0L,
    val equippedKnife: String = "knife_default",
    val equippedRifle: String = "ak47_default",
    val equippedPistol: String = "glock18_default",
    val equippedSniper: String = "awp_default",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class InventoryItem(
    @DocumentId val id: String = "",
    val userId: String = "",
    val skinId: String = "",
    val weaponName: String = "",
    val skinName: String = "",
    val rarity: String = "Mil-Spec",
    val wear: String = "Field-Tested",
    val isStatTrak: Boolean = false,
    val killsCount: Long = 0L,
    @ServerTimestamp val acquiredAt: Timestamp? = null
)

@IgnoreExtraProperties
data class QueueTicket(
    val userId: String = "",
    val displayName: String = "",
    val rankTier: String = "Silver I",
    val rankPoints: Long = 1000L,
    val gameMode: String = "1v1",
    val status: String = "waiting", // waiting, matched, cancelled
    val matchId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class MatchRoom(
    @DocumentId val id: String = "",
    val hostId: String = "",
    val guestId: String = "",
    val hostName: String = "",
    val guestName: String = "",
    val gameMode: String = "1v1",
    val mapName: String = "Dust II",
    val status: String = "waiting", // waiting, in_progress, finished
    val winnerId: String = "",
    val hostScore: Long = 0L,
    val guestScore: Long = 0L,
    val roundNumber: Long = 1L,
    val maxRounds: Long = 5L,
    val lastAction: String = "Match initialized",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class MarketplaceListing(
    @DocumentId val id: String = "",
    val sellerId: String = "",
    val sellerName: String = "",
    val skinId: String = "",
    val weaponName: String = "",
    val skinName: String = "",
    val rarity: String = "Mil-Spec",
    val wear: String = "Field-Tested",
    val isStatTrak: Boolean = false,
    val priceCoins: Long = 150L,
    val status: String = "active", // active, sold, cancelled
    val buyerId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class CommunityMap(
    @DocumentId val id: String = "",
    val creatorId: String = "",
    val creatorName: String = "",
    val title: String = "",
    val description: String = "",
    val gridData: String = "",
    val width: Long = 20L,
    val height: Long = 20L,
    val upvotes: Long = 0L,
    val playsCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

// Weapon definition for in-game mechanics
enum class WeaponType(val category: String, val slot: Int) {
    KNIFE("Melee", 3),
    PISTOL("Secondary", 2),
    RIFLE("Primary", 1),
    SNIPER("Primary", 1),
    GRENADE("Utility", 4),
    BOMB("Objective", 5)
}

data class WeaponArchetype(
    val id: String,
    val name: String,
    val type: WeaponType,
    val damage: Int,
    val fireRateMs: Long,
    val magSize: Int,
    val reloadTimeMs: Long,
    val cost: Int,
    val hasScope: Boolean = false,
    val killReward: Int = 300,
    val spread: Float = 0.05f
)

data class SkinDef(
    val skinId: String,
    val weaponName: String,
    val skinName: String,
    val rarity: String, // Consumer, Industrial, Mil-Spec, Restricted, Classified, Covert, Rare Special (Knife)
    val colorHex: Long,
    val basePrice: Int,
    val patternDescription: String
)
