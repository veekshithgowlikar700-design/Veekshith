package com.example.data.model

object GameCatalog {
    val WEAPONS = listOf(
        WeaponArchetype("knife_default", "Combat Knife", WeaponType.KNIFE, damage = 55, fireRateMs = 400L, magSize = 1, reloadTimeMs = 0L, cost = 0, killReward = 1500, spread = 0.01f),
        WeaponArchetype("glock18", "Glock-18", WeaponType.PISTOL, damage = 28, fireRateMs = 150L, magSize = 20, reloadTimeMs = 2100L, cost = 200, killReward = 300, spread = 0.04f),
        WeaponArchetype("usps", "USP-S", WeaponType.PISTOL, damage = 35, fireRateMs = 175L, magSize = 12, reloadTimeMs = 2200L, cost = 200, killReward = 300, spread = 0.02f),
        WeaponArchetype("deagle", "Desert Eagle", WeaponType.PISTOL, damage = 63, fireRateMs = 220L, magSize = 7, reloadTimeMs = 2400L, cost = 700, killReward = 300, spread = 0.03f),
        WeaponArchetype("ak47", "AK-47", WeaponType.RIFLE, damage = 36, fireRateMs = 100L, magSize = 30, reloadTimeMs = 2500L, cost = 2700, killReward = 300, spread = 0.035f),
        WeaponArchetype("m4a4", "M4A4", WeaponType.RIFLE, damage = 33, fireRateMs = 90L, magSize = 30, reloadTimeMs = 3100L, cost = 3100, killReward = 300, spread = 0.025f),
        WeaponArchetype("awp", "AWP", WeaponType.SNIPER, damage = 115, fireRateMs = 1400L, magSize = 5, reloadTimeMs = 3600L, cost = 4750, hasScope = true, killReward = 100, spread = 0.005f),
        WeaponArchetype("c4_bomb", "C4 Explosive", WeaponType.BOMB, damage = 500, fireRateMs = 1000L, magSize = 1, reloadTimeMs = 0L, cost = 0, killReward = 0, spread = 0.0f)
    )

    val SKINS = listOf(
        // Covert & Rare Special (Knives)
        SkinDef("karambit_fade", "Karambit", "Fade", "Rare Special", 0xFFFFD700, 3500, "Vibrant rainbow gradient with golden brass ring"),
        SkinDef("butterfly_doppler", "Butterfly Knife", "Doppler Phase 4", "Rare Special", 0xFFFFD700, 4200, "Deep oceanic sapphire and smoke twirling balisong"),
        SkinDef("m9_crimson_web", "M9 Bayonet", "Crimson Web", "Rare Special", 0xFFFFD700, 2800, "Blood-red lacquer laced with dark spiderweb patterns"),
        
        // AWP
        SkinDef("awp_dragon_lore", "AWP", "Dragon Lore", "Covert", 0xFFEB4B4B, 5000, "Knotwork dragon breathing flame across golden cobblestone"),
        SkinDef("awp_asiimov", "AWP", "Asiimov", "Covert", 0xFFEB4B4B, 1800, "Sci-fi high-contrast white, orange, and matte black geometry"),
        SkinDef("awp_hyper_beast", "AWP", "Hyper Beast", "Covert", 0xFFEB4B4B, 1200, "Psychedelic beast with vibrant tentacles and sharp fangs"),
        
        // AK-47
        SkinDef("ak47_case_hardened", "AK-47", "Case Hardened (Blue Gem)", "Classified", 0xFFD32CE6, 2400, "Patina blue titanium heat treated receiver"),
        SkinDef("ak47_vulcan", "AK-47", "Vulcan", "Covert", 0xFFEB4B4B, 1500, "Sporty composite carbon fiber with cyan racing stripes"),
        SkinDef("ak47_fire_serpent", "AK-47", "Fire Serpent", "Covert", 0xFFEB4B4B, 3200, "Mayan feathered serpent wrapped around wooden stock"),
        SkinDef("ak47_redline", "AK-47", "Redline", "Classified", 0xFFD32CE6, 650, "Carbon fiber body lined with aggressive crimson pinstripes"),
        
        // M4A4
        SkinDef("m4a4_howl", "M4A4", "Howl", "Contraband", 0xFFFF5722, 6000, "Roaring red hellhound emerging from blazing embers"),
        SkinDef("m4a4_emperor", "M4A4", "The Emperor", "Covert", 0xFFEB4B4B, 1400, "Majestic royal golden emperor crowned in lapis lazuli"),
        SkinDef("m4a4_neo_noir", "M4A4", "Neo-Noir", "Covert", 0xFFEB4B4B, 950, "Stylized comic noir illustration in magenta and ice cyan"),

        // Pistols
        SkinDef("deagle_blaze", "Desert Eagle", "Blaze", "Restricted", 0xFF8847FF, 2100, "Hotrod flame paintjob trailing from muzzle to slide"),
        SkinDef("deagle_printstream", "Desert Eagle", "Printstream", "Covert", 0xFFEB4B4B, 1100, "Clean iridescent white with holographic optical accents"),
        SkinDef("glock_fade", "Glock-18", "Fade", "Restricted", 0xFF8847FF, 1600, "Anodized airbrushed chrome with multi-color transition"),
        SkinDef("glock_water_elemental", "Glock-18", "Water Elemental", "Classified", 0xFFD32CE6, 450, "Surging aquatic beast splashing along the red frame"),
        SkinDef("usps_kill_confirmed", "USP-S", "Kill Confirmed", "Covert", 0xFFEB4B4B, 1300, "Shattering crimson skull pierced by a high-velocity bullet")
    )

    val RANK_TIERS = listOf(
        RankTierInfo("Silver I", 0, 1100, 0xFF9E9E9E),
        RankTierInfo("Silver Elite Master", 1101, 1300, 0xFFB0BEC5),
        RankTierInfo("Gold Nova I", 1301, 1500, 0xFFFFD54F),
        RankTierInfo("Gold Nova Master", 1501, 1750, 0xFFFFB300),
        RankTierInfo("Master Guardian I", 1751, 2000, 0xFF42A5F5),
        RankTierInfo("Master Guardian Elite", 2001, 2300, 0xFF1E88E5),
        RankTierInfo("Legendary Eagle", 2301, 2600, 0xFFAB47BC),
        RankTierInfo("Supreme Master First Class", 2601, 3000, 0xFF8E24AA),
        RankTierInfo("The Global Elite", 3001, 99999, 0xFFFF7043)
    )

    fun getTierForPoints(points: Long): RankTierInfo {
        return RANK_TIERS.firstOrNull { points in it.minPoints..it.maxPoints } ?: RANK_TIERS.last()
    }

    val PRELOADED_MAPS = listOf(
        MapBlueprint(
            id = "dust2",
            name = "Dust II",
            description = "Iconic Middle Eastern desert layout with Long A, Catwalk, Mid Doors, and B Tunnels.",
            width = 16,
            height = 16,
            spawnT = Pair(2, 14),
            spawnCT = Pair(14, 2),
            siteA = Pair(13, 13),
            siteB = Pair(2, 2)
        ),
        MapBlueprint(
            id = "mirage",
            name = "Mirage",
            description = "Balanced tournament classic featuring A Ramp, Palace, Mid Window, and B Apartments.",
            width = 16,
            height = 16,
            spawnT = Pair(1, 8),
            spawnCT = Pair(14, 8),
            siteA = Pair(12, 13),
            siteB = Pair(12, 2)
        ),
        MapBlueprint(
            id = "inferno",
            name = "Inferno",
            description = "Choke-point heavy Italian village with Banana, Apartments, Pit, and Church.",
            width = 16,
            height = 16,
            spawnT = Pair(1, 14),
            spawnCT = Pair(14, 1),
            siteA = Pair(13, 10),
            siteB = Pair(4, 2)
        ),
        MapBlueprint(
            id = "aim_map",
            name = "Aim_Map 1v1",
            description = "Pure symmetrical duel arena with center crates, side peek walls, and rifle spawns.",
            width = 12,
            height = 12,
            spawnT = Pair(2, 6),
            spawnCT = Pair(10, 6),
            siteA = Pair(6, 6),
            siteB = Pair(6, 6)
        )
    )
}

data class RankTierInfo(
    val name: String,
    val minPoints: Long,
    val maxPoints: Long,
    val colorHex: Long
)

data class MapBlueprint(
    val id: String,
    val name: String,
    val description: String,
    val width: Int,
    val height: Int,
    val spawnT: Pair<Int, Int>,
    val spawnCT: Pair<Int, Int>,
    val siteA: Pair<Int, Int>,
    val siteB: Pair<Int, Int>
)
