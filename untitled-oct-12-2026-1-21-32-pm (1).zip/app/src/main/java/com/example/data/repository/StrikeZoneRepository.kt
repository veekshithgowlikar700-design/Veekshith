package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.CommunityMap
import com.example.data.model.GameCatalog
import com.example.data.model.InventoryItem
import com.example.data.model.MarketplaceListing
import com.example.data.model.MatchRoom
import com.example.data.model.OperationType
import com.example.data.model.QueueTicket
import com.example.data.model.UserProfile
import com.example.data.model.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class StrikeZoneRepository(
    private val db: FirebaseFirestore,
    private val auth: com.google.firebase.auth.FirebaseAuth = Firebase.auth
) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        Firebase.auth
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    // 1. Profile operations
    fun observeUserProfile(): Flow<UserProfile?> = flow {
        val uid = requireUserId()
        val path = "users/$uid"
        val docRef = db.collection("users").document(uid)
        
        docRef.snapshots()
            .map { snapshot -> snapshot.toObject(UserProfile::class.java) }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.GET, path)
                throw error
            }
            .collect { emit(it) }
    }

    suspend fun getOrCreateProfile(displayName: String, email: String, photoUrl: String): UserProfile {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)
        val snapshot = docRef.get().await()
        if (snapshot.exists()) {
            return snapshot.toObject(UserProfile::class.java) ?: UserProfile(userId = uid, displayName = displayName)
        }
        val newProfile = UserProfile(
            userId = uid,
            displayName = displayName.ifBlank { "Agent_${uid.take(4)}" },
            email = email,
            photoUrl = photoUrl,
            coins = 800L, // Starter bonus coins
            rankPoints = 1200L,
            rankTier = "Silver Elite Master",
            kills = 0L,
            deaths = 0L,
            headshots = 0L,
            wins = 0L,
            losses = 0L,
            equippedKnife = "karambit_fade",
            equippedRifle = "ak47_vulcan",
            equippedPistol = "deagle_blaze",
            equippedSniper = "awp_asiimov"
        )
        val payload = mapOf(
            "userId" to uid,
            "displayName" to newProfile.displayName,
            "email" to newProfile.email,
            "photoUrl" to newProfile.photoUrl,
            "coins" to newProfile.coins,
            "rankPoints" to newProfile.rankPoints,
            "rankTier" to newProfile.rankTier,
            "kills" to newProfile.kills,
            "deaths" to newProfile.deaths,
            "headshots" to newProfile.headshots,
            "wins" to newProfile.wins,
            "losses" to newProfile.losses,
            "equippedKnife" to newProfile.equippedKnife,
            "equippedRifle" to newProfile.equippedRifle,
            "equippedPistol" to newProfile.equippedPistol,
            "equippedSniper" to newProfile.equippedSniper,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        docRef.set(payload).await()
        
        // Give starter skin
        addStarterSkins(uid)
        return newProfile
    }

    private suspend fun addStarterSkins(uid: String) {
        val inventoryRef = db.collection("users").document(uid).collection("inventory")
        val starterSkins = listOf(
            mapOf(
                "userId" to uid,
                "skinId" to "ak47_vulcan",
                "weaponName" to "AK-47",
                "skinName" to "Vulcan",
                "rarity" to "Covert",
                "wear" to "Factory New",
                "isStatTrak" to true,
                "killsCount" to 12L,
                "acquiredAt" to FieldValue.serverTimestamp()
            ),
            mapOf(
                "userId" to uid,
                "skinId" to "awp_asiimov",
                "weaponName" to "AWP",
                "skinName" to "Asiimov",
                "rarity" to "Covert",
                "wear" to "Field-Tested",
                "isStatTrak" to false,
                "killsCount" to 0L,
                "acquiredAt" to FieldValue.serverTimestamp()
            ),
            mapOf(
                "userId" to uid,
                "skinId" to "karambit_fade",
                "weaponName" to "Karambit",
                "skinName" to "Fade",
                "rarity" to "Rare Special",
                "wear" to "Factory New",
                "isStatTrak" to true,
                "killsCount" to 4L,
                "acquiredAt" to FieldValue.serverTimestamp()
            )
        )
        for (item in starterSkins) {
            inventoryRef.add(item).await()
        }
    }

    suspend fun updateMatchStats(kills: Long, headshots: Long, won: Boolean) {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)
        val snapshot = docRef.get().await()
        val current = snapshot.toObject(UserProfile::class.java) ?: return

        val newKills = current.kills + kills
        val newDeaths = current.deaths + (if (won) 0L else 1L)
        val newHeadshots = current.headshots + headshots
        val newWins = current.wins + (if (won) 1L else 0L)
        val newLosses = current.losses + (if (won) 0L else 1L)
        val eloDelta = if (won) 25L else -15L
        val newElo = (current.rankPoints + eloDelta).coerceAtLeast(100L)
        val newTier = GameCatalog.getTierForPoints(newElo).name
        val coinsReward = if (won) 150L else 50L

        docRef.update(
            mapOf(
                "kills" to newKills,
                "deaths" to newDeaths,
                "headshots" to newHeadshots,
                "wins" to newWins,
                "losses" to newLosses,
                "rankPoints" to newElo,
                "rankTier" to newTier,
                "coins" to current.coins + coinsReward,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
    }

    suspend fun equipSkin(category: String, skinId: String) {
        val uid = requireUserId()
        val field = when (category.lowercase()) {
            "knife" -> "equippedKnife"
            "rifle" -> "equippedRifle"
            "pistol" -> "equippedPistol"
            "sniper" -> "equippedSniper"
            else -> "equippedRifle"
        }
        db.collection("users").document(uid).update(field, skinId, "updatedAt", FieldValue.serverTimestamp()).await()
    }

    // 2. Inventory operations
    fun observeInventory(): Flow<List<InventoryItem>> = flow {
        val uid = requireUserId()
        val path = "users/$uid/inventory"
        db.collection("users").document(uid).collection("inventory")
            .snapshots()
            .map { snapshot -> snapshot.toObjects(InventoryItem::class.java) }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                throw error
            }
            .collect { emit(it) }
    }

    suspend fun addSkinToInventory(skin: com.example.data.model.SkinDef, wear: String, isStatTrak: Boolean): String {
        val uid = requireUserId()
        val inventoryRef = db.collection("users").document(uid).collection("inventory")
        val docRef = inventoryRef.add(
            mapOf(
                "userId" to uid,
                "skinId" to skin.skinId,
                "weaponName" to skin.weaponName,
                "skinName" to skin.skinName,
                "rarity" to skin.rarity,
                "wear" to wear,
                "isStatTrak" to isStatTrak,
                "killsCount" to 0L,
                "acquiredAt" to FieldValue.serverTimestamp()
            )
        ).await()
        return docRef.id
    }

    // 3. Matchmaking Queue & 1v1
    suspend fun joinMatchmakingQueue(displayName: String, rankTier: String, rankPoints: Long, gameMode: String): String {
        val uid = requireUserId()
        val ticketRef = db.collection("matchmaking_queue").document(uid)
        ticketRef.set(
            mapOf(
                "userId" to uid,
                "displayName" to displayName,
                "rankTier" to rankTier,
                "rankPoints" to rankPoints,
                "gameMode" to gameMode,
                "status" to "waiting",
                "createdAt" to FieldValue.serverTimestamp()
            )
        ).await()
        return uid
    }

    suspend fun cancelQueue() {
        val uid = requireUserId()
        db.collection("matchmaking_queue").document(uid).delete().await()
    }

    suspend fun createMatchRoom(opponentId: String, opponentName: String, gameMode: String, mapName: String): String {
        val uid = requireUserId()
        val matchRef = db.collection("matches").document()
        matchRef.set(
            mapOf(
                "hostId" to uid,
                "guestId" to opponentId,
                "hostName" to (auth.currentUser?.displayName ?: "Player 1"),
                "guestName" to opponentName,
                "gameMode" to gameMode,
                "mapName" to mapName,
                "status" to "in_progress",
                "hostScore" to 0L,
                "guestScore" to 0L,
                "roundNumber" to 1L,
                "maxRounds" to 5L,
                "lastAction" to "Round 1 started! Terrorists vs Counter-Terrorists",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
        return matchRef.id
    }

    fun observeMatch(matchId: String): Flow<MatchRoom?> = flow {
        val docRef = db.collection("matches").document(matchId)
        docRef.snapshots()
            .map { snapshot -> snapshot.toObject(MatchRoom::class.java) }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.GET, "matches/$matchId")
                throw error
            }
            .collect { emit(it) }
    }

    suspend fun updateMatchScore(matchId: String, hostScore: Long, guestScore: Long, roundNumber: Long, action: String, isFinished: Boolean, winnerId: String = "") {
        val payload = mutableMapOf<String, Any>(
            "hostScore" to hostScore,
            "guestScore" to guestScore,
            "roundNumber" to roundNumber,
            "lastAction" to action,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (isFinished) {
            payload["status"] = "finished"
            payload["winnerId"] = winnerId
        }
        db.collection("matches").document(matchId).update(payload).await()
    }

    // 4. Skin Marketplace
    fun observeMarketplace(): Flow<List<MarketplaceListing>> = flow {
        db.collection("marketplace_listings")
            .whereEqualTo("status", "active")
            .snapshots()
            .map { snapshot -> snapshot.toObjects(MarketplaceListing::class.java) }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, "marketplace_listings")
                throw error
            }
            .collect { emit(it) }
    }

    suspend fun listSkinOnMarket(item: InventoryItem, priceCoins: Long): String {
        val uid = requireUserId()
        val docRef = db.collection("marketplace_listings").document()
        docRef.set(
            mapOf(
                "sellerId" to uid,
                "sellerName" to (auth.currentUser?.displayName ?: "Seller"),
                "skinId" to item.skinId,
                "weaponName" to item.weaponName,
                "skinName" to item.skinName,
                "rarity" to item.rarity,
                "wear" to item.wear,
                "isStatTrak" to item.isStatTrak,
                "priceCoins" to priceCoins,
                "status" to "active",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()

        // Remove item from user's local inventory
        if (item.id.isNotBlank()) {
            db.collection("users").document(uid).collection("inventory").document(item.id).delete().await()
        }
        return docRef.id
    }

    suspend fun buySkinFromMarket(listing: MarketplaceListing): Boolean {
        val uid = requireUserId()
        val userDoc = db.collection("users").document(uid).get().await()
        val user = userDoc.toObject(UserProfile::class.java) ?: return false
        if (user.coins < listing.priceCoins) return false

        // Deduct coins
        db.collection("users").document(uid).update(
            "coins", user.coins - listing.priceCoins,
            "updatedAt", FieldValue.serverTimestamp()
        ).await()

        // Credit seller coins
        val sellerRef = db.collection("users").document(listing.sellerId)
        val sellerDoc = sellerRef.get().await()
        if (sellerDoc.exists()) {
            val seller = sellerDoc.toObject(UserProfile::class.java)
            if (seller != null) {
                sellerRef.update("coins", seller.coins + listing.priceCoins).await()
            }
        }

        // Add skin to buyer inventory
        db.collection("users").document(uid).collection("inventory").add(
            mapOf(
                "userId" to uid,
                "skinId" to listing.skinId,
                "weaponName" to listing.weaponName,
                "skinName" to listing.skinName,
                "rarity" to listing.rarity,
                "wear" to listing.wear,
                "isStatTrak" to listing.isStatTrak,
                "killsCount" to 0L,
                "acquiredAt" to FieldValue.serverTimestamp()
            )
        ).await()

        // Mark listing sold
        db.collection("marketplace_listings").document(listing.id).update(
            mapOf(
                "status" to "sold",
                "buyerId" to uid,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()

        return true
    }

    // 5. Community Maps
    fun observeCommunityMaps(): Flow<List<CommunityMap>> = flow {
        db.collection("community_maps")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .snapshots()
            .map { snapshot -> snapshot.toObjects(CommunityMap::class.java) }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, "community_maps")
                throw error
            }
            .collect { emit(it) }
    }

    suspend fun publishCommunityMap(title: String, description: String, gridData: String, width: Long, height: Long): String {
        val uid = requireUserId()
        val mapRef = db.collection("community_maps").document()
        mapRef.set(
            mapOf(
                "creatorId" to uid,
                "creatorName" to (auth.currentUser?.displayName ?: "Mapper"),
                "title" to title,
                "description" to description,
                "gridData" to gridData,
                "width" to width,
                "height" to height,
                "upvotes" to 0L,
                "playsCount" to 0L,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
        return mapRef.id
    }

    suspend fun upvoteCommunityMap(mapId: String) {
        db.collection("community_maps").document(mapId).update(
            "upvotes", FieldValue.increment(1L),
            "updatedAt", FieldValue.serverTimestamp()
        ).await()
    }
}
