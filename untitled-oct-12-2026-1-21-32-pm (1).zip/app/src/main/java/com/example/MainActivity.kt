package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import com.example.ui.ScreenState
import com.example.ui.StrikeZoneViewModel
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CaseOpeningScreen
import com.example.ui.screens.CommunityMapsScreen
import com.example.ui.screens.GamePlayScreen
import com.example.ui.screens.InventoryScreen
import com.example.ui.screens.LobbyScreen
import com.example.ui.screens.MapEditorScreen
import com.example.ui.screens.MarketplaceScreen
import com.example.ui.screens.RankedLeaguesScreen
import com.example.ui.screens.attemptAutoSignIn
import com.example.ui.screens.signOut
import com.example.ui.theme.StrikeZoneTheme
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

class MainActivity : ComponentActivity() {

    private val viewModel: StrikeZoneViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            StrikeZoneTheme {
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .safeDrawingPadding(),
                    color = Color(0xFF0F1318)
                ) {
                    AppContent(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun AppContent(viewModel: StrikeZoneViewModel) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose {
            Firebase.auth.removeAuthStateListener(listener)
        }
    }

    LaunchedEffect(Unit) {
        if (currentUser == null) {
            attemptAutoSignIn(
                context = context,
                credentialManager = credentialManager,
                onAuthSuccess = { currentUser = Firebase.auth.currentUser },
                onUnauthenticated = {},
                scope = coroutineScope
            )
        }
    }

    if (currentUser == null) {
        AuthScreen(
            onAuthSuccess = {
                val user = Firebase.auth.currentUser
                currentUser = user
                if (user != null) {
                    viewModel.onAuthSuccess(user)
                }
            }
        )
    } else {
        MainGameNavigation(
            viewModel = viewModel,
            onSignOut = {
                signOut(
                    context = context,
                    credentialManager = credentialManager,
                    onSignOutComplete = { currentUser = null },
                    scope = coroutineScope
                )
            }
        )
    }
}

@Composable
fun MainGameNavigation(
    viewModel: StrikeZoneViewModel,
    onSignOut: () -> Unit
) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val selectedMap by viewModel.selectedMap.collectAsState()
    val isMultiplayer by viewModel.isMultiplayerMatch.collectAsState()

    // Immersive full-screen for active combat gameplay
    if (currentScreen == ScreenState.GAMEPLAY) {
        GamePlayScreen(
            viewModel = viewModel,
            map = selectedMap,
            isMultiplayer = isMultiplayer,
            onExit = { viewModel.navigateTo(ScreenState.LOBBY) }
        )
        return
    }

    // Material 3 Navigation Structure connecting Main Menu, Marketplace, Game, and Hubs
    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF141A23),
                contentColor = Color.White
            ) {
                // 1. Main Menu (Lobby)
                NavigationBarItem(
                    selected = currentScreen == ScreenState.LOBBY || currentScreen == ScreenState.RANKED_LEAGUES,
                    onClick = { viewModel.navigateTo(ScreenState.LOBBY) },
                    icon = { Icon(Icons.Default.SportsEsports, contentDescription = "Main Menu", modifier = Modifier.size(22.dp)) },
                    label = { Text("Menu", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = Color(0xFFFF9800),
                        indicatorColor = Color(0xFFFF9800),
                        unselectedIconColor = Color(0xFF90A4AE),
                        unselectedTextColor = Color(0xFF90A4AE)
                    ),
                    modifier = Modifier.testTag("nav_item_main_menu")
                )

                // 2. Game Screen
                NavigationBarItem(
                    selected = currentScreen == ScreenState.GAMEPLAY,
                    onClick = { viewModel.start1v1Match() },
                    icon = { Icon(Icons.Default.GpsFixed, contentDescription = "Game", modifier = Modifier.size(22.dp)) },
                    label = { Text("Game", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = Color(0xFFFF9800),
                        indicatorColor = Color(0xFFFF9800),
                        unselectedIconColor = Color(0xFF90A4AE),
                        unselectedTextColor = Color(0xFF90A4AE)
                    ),
                    modifier = Modifier.testTag("nav_item_game")
                )

                // 3. Marketplace Screen
                NavigationBarItem(
                    selected = currentScreen == ScreenState.MARKETPLACE,
                    onClick = { viewModel.navigateTo(ScreenState.MARKETPLACE) },
                    icon = { Icon(Icons.Default.ShoppingBag, contentDescription = "Marketplace", modifier = Modifier.size(22.dp)) },
                    label = { Text("Market", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = Color(0xFFFF9800),
                        indicatorColor = Color(0xFFFF9800),
                        unselectedIconColor = Color(0xFF90A4AE),
                        unselectedTextColor = Color(0xFF90A4AE)
                    ),
                    modifier = Modifier.testTag("nav_item_marketplace")
                )

                // 4. Inventory
                NavigationBarItem(
                    selected = currentScreen == ScreenState.INVENTORY || currentScreen == ScreenState.CASE_OPENING,
                    onClick = { viewModel.navigateTo(ScreenState.INVENTORY) },
                    icon = { Icon(Icons.Default.Shield, contentDescription = "Inventory", modifier = Modifier.size(22.dp)) },
                    label = { Text("Loadout", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = Color(0xFFFF9800),
                        indicatorColor = Color(0xFFFF9800),
                        unselectedIconColor = Color(0xFF90A4AE),
                        unselectedTextColor = Color(0xFF90A4AE)
                    ),
                    modifier = Modifier.testTag("nav_item_inventory")
                )

                // 5. Map Editor
                NavigationBarItem(
                    selected = currentScreen == ScreenState.MAP_EDITOR || currentScreen == ScreenState.COMMUNITY_MAPS,
                    onClick = { viewModel.navigateTo(ScreenState.MAP_EDITOR) },
                    icon = { Icon(Icons.Default.Handyman, contentDescription = "Map Editor", modifier = Modifier.size(22.dp)) },
                    label = { Text("Editor", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = Color(0xFFFF9800),
                        indicatorColor = Color(0xFFFF9800),
                        unselectedIconColor = Color(0xFF90A4AE),
                        unselectedTextColor = Color(0xFF90A4AE)
                    ),
                    modifier = Modifier.testTag("nav_item_map_editor")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                ScreenState.LOBBY -> {
                    LobbyScreen(
                        viewModel = viewModel,
                        onSignOut = onSignOut
                    )
                }
                ScreenState.GAMEPLAY -> {
                    GamePlayScreen(
                        viewModel = viewModel,
                        map = selectedMap,
                        isMultiplayer = isMultiplayer,
                        onExit = { viewModel.navigateTo(ScreenState.LOBBY) }
                    )
                }
                ScreenState.MARKETPLACE -> {
                    MarketplaceScreen(
                        viewModel = viewModel,
                        onBack = { viewModel.navigateTo(ScreenState.LOBBY) }
                    )
                }
                ScreenState.CASE_OPENING -> {
                    CaseOpeningScreen(
                        viewModel = viewModel,
                        onBack = { viewModel.navigateTo(ScreenState.LOBBY) }
                    )
                }
                ScreenState.RANKED_LEAGUES -> {
                    RankedLeaguesScreen(
                        viewModel = viewModel,
                        onBack = { viewModel.navigateTo(ScreenState.LOBBY) }
                    )
                }
                ScreenState.MAP_EDITOR -> {
                    MapEditorScreen(
                        viewModel = viewModel,
                        onBack = { viewModel.navigateTo(ScreenState.LOBBY) }
                    )
                }
                ScreenState.COMMUNITY_MAPS -> {
                    CommunityMapsScreen(
                        viewModel = viewModel,
                        onBack = { viewModel.navigateTo(ScreenState.LOBBY) }
                    )
                }
                ScreenState.INVENTORY -> {
                    InventoryScreen(
                        viewModel = viewModel,
                        onBack = { viewModel.navigateTo(ScreenState.LOBBY) }
                    )
                }
            }
        }
    }
}
