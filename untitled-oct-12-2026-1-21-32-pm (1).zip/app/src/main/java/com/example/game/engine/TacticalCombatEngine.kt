package com.example.game.engine

import com.example.data.model.GameCatalog
import com.example.data.model.MapBlueprint
import com.example.data.model.WeaponArchetype
import com.example.data.model.WeaponType
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random

data class SmokeCloud(
    val x: Float,
    val y: Float,
    var remainingSeconds: Float = 15f
)

data class ActiveGrenade(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val type: String, // "smoke", "flash", "he"
    var fuseSeconds: Float = 1.8f
)

data class PlayerActor(
    var id: String,
    var name: String,
    var isCT: Boolean,
    var x: Float,
    var y: Float,
    var vx: Float = 0f,
    var vy: Float = 0f,
    var angleDeg: Float = 0f,
    var health: Int = 100,
    var armor: Int = 0,
    var hasHelmet: Boolean = false,
    var hasDefuseKit: Boolean = false,
    var money: Int = 800,
    var activeWeapon: WeaponArchetype,
    var secondaryWeapon: WeaponArchetype,
    var knifeWeapon: WeaponArchetype,
    var smokeCount: Int = 0,
    var flashCount: Int = 0,
    var heCount: Int = 0,
    var ammoInMag: Int,
    var reserveAmmo: Int = 90,
    var isAlive: Boolean = true,
    var isReloading: Boolean = false,
    var reloadTimerMs: Long = 0L,
    var isScoped: Boolean = false,
    var isCrouching: Boolean = false,
    var isWalking: Boolean = false,
    var recoilSpread: Float = 0f,
    var burstShotIndex: Int = 0,
    var lastBurstTimeMs: Long = 0L,
    var isPlanting: Boolean = false,
    var isDefusing: Boolean = false,
    var plantDefuseProgress: Float = 0f,
    var flashDurationSeconds: Float = 0f
)

data class BombState(
    var isPlanted: Boolean = false,
    var x: Float = 0f,
    var y: Float = 0f,
    var timerSeconds: Float = 40f,
    var isDefused: Boolean = false,
    var isDetonated: Boolean = false,
    var site: String = "A"
)

enum class RoundOutcome {
    IN_PROGRESS,
    CT_ELIMINATION,
    T_ELIMINATION,
    BOMB_DEFUSED,
    BOMB_DETONATED,
    TIME_EXPIRED
}

data class CombatFeedItem(
    val killer: String,
    val victim: String,
    val weapon: String,
    val isHeadshot: Boolean
)

class TacticalCombatEngine(
    val map: MapBlueprint,
    val isMultiplayer: Boolean = false
) {
    // 0: Floor, 1: Wall, 2: Crate, 3: Site A, 4: Site B, 5: T Spawn, 6: CT Spawn
    val grid: Array<IntArray> = Array(map.height) { y ->
        IntArray(map.width) { x ->
            when {
                x == 0 || x == map.width - 1 || y == 0 || y == map.height - 1 -> 1
                (x == 4 && y in 3..7) || (x == 11 && y in 8..12) -> 1
                (x in 7..8 && y in 5..7) -> 1
                (x == 6 && y == 4) || (x == 9 && y == 11) -> 2
                x == map.siteA.first && y == map.siteA.second -> 3
                x == map.siteB.first && y == map.siteB.second -> 4
                x == map.spawnT.first && y == map.spawnT.second -> 5
                x == map.spawnCT.first && y == map.spawnCT.second -> 6
                else -> 0
            }
        }
    }

    var localPlayer: PlayerActor
    var opponent: PlayerActor
    var bomb = BombState()
    var roundTimeSeconds = 115f
    var roundOutcome = RoundOutcome.IN_PROGRESS
    var ctScore = 0
    var tScore = 0
    var currentRound = 1
    val maxRounds = 5
    var lastShootTimestamp = 0L

    var ctLossStreak = 0
    var tLossStreak = 0

    val killFeed = mutableListOf<CombatFeedItem>()
    val smokeClouds = mutableListOf<SmokeCloud>()
    val activeGrenades = mutableListOf<ActiveGrenade>()

    init {
        val glock = GameCatalog.WEAPONS.first { it.id == "glock18" }
        val usps = GameCatalog.WEAPONS.first { it.id == "usps" }
        val knife = GameCatalog.WEAPONS.first { it.id == "knife_default" }

        // Start of match: Pistol round ($800 starting money)
        localPlayer = PlayerActor(
            id = "local_player",
            name = "Player",
            isCT = true,
            x = map.spawnCT.first + 0.5f,
            y = map.spawnCT.second + 0.5f,
            angleDeg = 180f,
            money = 800,
            activeWeapon = usps,
            secondaryWeapon = usps,
            knifeWeapon = knife,
            ammoInMag = usps.magSize
        )

        opponent = PlayerActor(
            id = "bot_opponent",
            name = "s1mple_bot",
            isCT = false,
            x = map.spawnT.first + 0.5f,
            y = map.spawnT.second + 0.5f,
            angleDeg = 0f,
            money = 800,
            activeWeapon = glock,
            secondaryWeapon = glock,
            knifeWeapon = knife,
            ammoInMag = glock.magSize
        )
    }

    fun resetRound() {
        roundTimeSeconds = 115f
        roundOutcome = RoundOutcome.IN_PROGRESS
        bomb = BombState()
        smokeClouds.clear()
        activeGrenades.clear()

        resetPlayerForRound(localPlayer, isCT = localPlayer.isCT)
        resetPlayerForRound(opponent, isCT = opponent.isCT)

        // Bot economy logic
        if (!isMultiplayer) {
            handleBotEconomy()
        }
    }

    private fun resetPlayerForRound(player: PlayerActor, isCT: Boolean) {
        player.x = if (isCT) map.spawnCT.first + 0.5f else map.spawnT.first + 0.5f
        player.y = if (isCT) map.spawnCT.second + 0.5f else map.spawnT.second + 0.5f
        player.vx = 0f
        player.vy = 0f
        player.health = 100
        player.isAlive = true
        player.isReloading = false
        player.isPlanting = false
        player.isDefusing = false
        player.isCrouching = false
        player.isWalking = false
        player.plantDefuseProgress = 0f
        player.burstShotIndex = 0
        player.recoilSpread = 0f
        player.flashDurationSeconds = 0f
        player.ammoInMag = player.activeWeapon.magSize
    }

    private fun handleBotEconomy() {
        val ak = GameCatalog.WEAPONS.first { it.id == "ak47" }
        val m4 = GameCatalog.WEAPONS.first { it.id == "m4a4" }
        val awp = GameCatalog.WEAPONS.first { it.id == "awp" }
        val deagle = GameCatalog.WEAPONS.first { it.id == "deagle" }

        if (opponent.money >= 4750 && currentRound >= 3 && Random.nextFloat() < 0.35f) {
            opponent.money -= 4750
            opponent.activeWeapon = awp
            opponent.ammoInMag = awp.magSize
            opponent.armor = 100
            opponent.hasHelmet = true
        } else if (opponent.money >= 2700) {
            val rifle = if (opponent.isCT) m4 else ak
            opponent.money -= rifle.cost
            opponent.activeWeapon = rifle
            opponent.ammoInMag = rifle.magSize
            opponent.armor = 100
            opponent.hasHelmet = true
        } else if (opponent.money >= 700) {
            opponent.money -= 700
            opponent.activeWeapon = deagle
            opponent.ammoInMag = deagle.magSize
        }
    }

    fun applyEconomyRoundEnd(winnerCT: Boolean, wasBombDetonatedOrDefused: Boolean) {
        val baseWinCash = if (wasBombDetonatedOrDefused) 3500 else 3250

        if (winnerCT) {
            // CT Won
            ctScore++
            localPlayer.money = (localPlayer.money + if (localPlayer.isCT) baseWinCash else calculateLossBonus(ctLossStreak)).coerceAtMost(16000)
            opponent.money = (opponent.money + if (opponent.isCT) baseWinCash else calculateLossBonus(tLossStreak)).coerceAtMost(16000)
            ctLossStreak = 0
            tLossStreak++
        } else {
            // T Won
            tScore++
            localPlayer.money = (localPlayer.money + if (!localPlayer.isCT) baseWinCash else calculateLossBonus(ctLossStreak)).coerceAtMost(16000)
            opponent.money = (opponent.money + if (!opponent.isCT) baseWinCash else calculateLossBonus(tLossStreak)).coerceAtMost(16000)
            tLossStreak = 0
            ctLossStreak++
        }
    }

    private fun calculateLossBonus(lossStreak: Int): Int {
        // CS:GO Loss bonus ladder: $1400 -> $1900 -> $2400 -> $2900 -> $3400
        val tier = lossStreak.coerceIn(0, 4)
        return 1400 + (tier * 500)
    }

    fun update(deltaSeconds: Float, nowMs: Long) {
        if (roundOutcome != RoundOutcome.IN_PROGRESS) return

        // Round timer
        if (!bomb.isPlanted) {
            roundTimeSeconds -= deltaSeconds
            if (roundTimeSeconds <= 0f) {
                roundTimeSeconds = 0f
                roundOutcome = RoundOutcome.TIME_EXPIRED
                applyEconomyRoundEnd(winnerCT = true, wasBombDetonatedOrDefused = false)
                return
            }
        } else {
            // Bomb ticking down
            bomb.timerSeconds -= deltaSeconds
            if (bomb.timerSeconds <= 0f) {
                bomb.timerSeconds = 0f
                bomb.isDetonated = true
                roundOutcome = RoundOutcome.BOMB_DETONATED
                applyEconomyRoundEnd(winnerCT = false, wasBombDetonatedOrDefused = true)
                return
            }
        }

        // Active Smokes update
        smokeClouds.removeAll { smoke ->
            smoke.remainingSeconds -= deltaSeconds
            smoke.remainingSeconds <= 0f
        }

        // Active Grenades update (physics & fuse)
        activeGrenades.removeAll { grenade ->
            grenade.x += grenade.vx * deltaSeconds
            grenade.y += grenade.vy * deltaSeconds
            grenade.vx *= 0.92f
            grenade.vy *= 0.92f
            grenade.fuseSeconds -= deltaSeconds

            if (grenade.fuseSeconds <= 0f) {
                detonateGrenade(grenade)
                true
            } else false
        }

        // Flash duration countdown
        if (localPlayer.flashDurationSeconds > 0f) {
            localPlayer.flashDurationSeconds = (localPlayer.flashDurationSeconds - deltaSeconds).coerceAtLeast(0f)
        }
        if (opponent.flashDurationSeconds > 0f) {
            opponent.flashDurationSeconds = (opponent.flashDurationSeconds - deltaSeconds).coerceAtLeast(0f)
        }

        // Handle reloading
        updateReload(localPlayer, deltaSeconds)
        updateReload(opponent, deltaSeconds)

        // Burst reset and recoil recovery
        if (nowMs - localPlayer.lastBurstTimeMs > 400L) {
            localPlayer.burstShotIndex = 0
            localPlayer.recoilSpread = (localPlayer.recoilSpread - deltaSeconds * 0.45f).coerceAtLeast(0f)
        }
        if (nowMs - opponent.lastBurstTimeMs > 400L) {
            opponent.burstShotIndex = 0
            opponent.recoilSpread = (opponent.recoilSpread - deltaSeconds * 0.45f).coerceAtLeast(0f)
        }

        // Handle planting / defusing
        handlePlantDefuse(localPlayer, deltaSeconds)
        handlePlantDefuse(opponent, deltaSeconds)

        // If playing with AI bot
        if (!isMultiplayer && opponent.isAlive) {
            updateBotAi(deltaSeconds, nowMs)
        }
    }

    private fun detonateGrenade(grenade: ActiveGrenade) {
        when (grenade.type) {
            "smoke" -> {
                smokeClouds.add(SmokeCloud(grenade.x, grenade.y))
            }
            "flash" -> {
                // Flash both actors if within range and LOS
                flashActor(localPlayer, grenade.x, grenade.y)
                flashActor(opponent, grenade.x, grenade.y)
            }
            "he" -> {
                damageNearbyActor(localPlayer, grenade.x, grenade.y)
                damageNearbyActor(opponent, grenade.x, grenade.y)
            }
        }
    }

    private fun flashActor(player: PlayerActor, gx: Float, gy: Float) {
        val dist = hypot(player.x - gx, player.y - gy)
        if (dist < 10f && hasLineOfSight(player.x, player.y, gx, gy)) {
            val duration = (4.5f - (dist * 0.35f)).coerceIn(0.5f, 4.0f)
            player.flashDurationSeconds = duration
        }
    }

    private fun damageNearbyActor(player: PlayerActor, gx: Float, gy: Float) {
        val dist = hypot(player.x - gx, player.y - gy)
        if (dist < 5f && hasLineOfSight(player.x, player.y, gx, gy)) {
            val dmg = ((5f - dist) * 15f).toInt()
            player.health = (player.health - dmg).coerceAtLeast(0)
            if (player.health <= 0) {
                player.isAlive = false
                val wonCT = !player.isCT
                roundOutcome = if (wonCT) RoundOutcome.CT_ELIMINATION else RoundOutcome.T_ELIMINATION
                applyEconomyRoundEnd(wonCT, false)
            }
        }
    }

    fun throwGrenade(player: PlayerActor, type: String): Boolean {
        val count = when (type) {
            "smoke" -> player.smokeCount
            "flash" -> player.flashCount
            "he" -> player.heCount
            else -> 0
        }
        if (count <= 0) return false

        when (type) {
            "smoke" -> player.smokeCount--
            "flash" -> player.flashCount--
            "he" -> player.heCount--
        }

        val rad = Math.toRadians(player.angleDeg.toDouble())
        val speed = 8.0f
        activeGrenades.add(
            ActiveGrenade(
                x = player.x,
                y = player.y,
                vx = cos(rad).toFloat() * speed,
                vy = sin(rad).toFloat() * speed,
                type = type
            )
        )
        return true
    }

    private fun updateReload(player: PlayerActor, deltaSeconds: Float) {
        if (player.isReloading) {
            player.reloadTimerMs -= (deltaSeconds * 1000).toLong()
            if (player.reloadTimerMs <= 0L) {
                player.isReloading = false
                player.ammoInMag = player.activeWeapon.magSize
            }
        }
    }

    private fun handlePlantDefuse(player: PlayerActor, deltaSeconds: Float) {
        if (player.isPlanting) {
            player.plantDefuseProgress += deltaSeconds / 3.5f
            if (player.plantDefuseProgress >= 1f) {
                player.isPlanting = false
                player.plantDefuseProgress = 0f
                bomb.isPlanted = true
                bomb.x = player.x
                bomb.y = player.y
                bomb.timerSeconds = 40f
            }
        } else if (player.isDefusing) {
            val defuseTime = if (player.hasDefuseKit) 5.0f else 10.0f
            player.plantDefuseProgress += deltaSeconds / defuseTime
            if (player.plantDefuseProgress >= 1f) {
                player.isDefusing = false
                player.plantDefuseProgress = 0f
                bomb.isDefused = true
                roundOutcome = RoundOutcome.BOMB_DEFUSED
                applyEconomyRoundEnd(winnerCT = true, wasBombDetonatedOrDefused = true)
            }
        }
    }

    // Movement with acceleration, friction, and counter-strafing
    fun movePlayer(player: PlayerActor, inputX: Float, inputY: Float, deltaSeconds: Float) {
        if (!player.isAlive || player.isPlanting || player.isDefusing) return

        val maxSpeed = when {
            player.isCrouching -> 1.8f
            player.isWalking -> 2.2f
            player.isScoped -> 1.4f
            player.activeWeapon.type == WeaponType.KNIFE -> 4.0f
            else -> 3.4f
        }

        if (inputX != 0f || inputY != 0f) {
            // Accelerate towards input
            player.vx = inputX * maxSpeed
            player.vy = inputY * maxSpeed
        } else {
            // Counter-strafing / instant friction stop
            player.vx *= 0.15f
            player.vy *= 0.15f
            if (hypot(player.vx, player.vy) < 0.05f) {
                player.vx = 0f
                player.vy = 0f
            }
        }

        val newX = player.x + player.vx * deltaSeconds
        val newY = player.y + player.vy * deltaSeconds

        if (canPass(newX, player.y)) player.x = newX.coerceIn(1.1f, map.width - 1.1f)
        if (canPass(player.x, newY)) player.y = newY.coerceIn(1.1f, map.height - 1.1f)
    }

    fun canPass(x: Float, y: Float): Boolean {
        val gx = x.toInt()
        val gy = y.toInt()
        if (gx !in 0 until map.width || gy !in 0 until map.height) return false
        val tile = grid[gy][gx]
        return tile != 1 && tile != 2
    }

    fun isAtBombSite(x: Float, y: Float): Boolean {
        val distA = hypot(x - (map.siteA.first + 0.5f), y - (map.siteA.second + 0.5f))
        val distB = hypot(x - (map.siteB.first + 0.5f), y - (map.siteB.second + 0.5f))
        return distA < 1.8f || distB < 1.8f
    }

    fun isNearPlantedBomb(x: Float, y: Float): Boolean {
        if (!bomb.isPlanted || bomb.isDefused || bomb.isDetonated) return false
        return hypot(x - bomb.x, y - bomb.y) < 1.6f
    }

    data class ShootResult(
        val fired: Boolean,
        val hit: Boolean,
        val headshot: Boolean,
        val damage: Int,
        val targetKilled: Boolean,
        val moneyEarned: Int = 0
    )

    // Accurate CS:GO spray pattern calculation
    private fun getSprayOffsetDeg(weaponId: String, shotIndex: Int): Pair<Float, Float> {
        val idx = shotIndex.coerceIn(0, 29)
        return when {
            weaponId.contains("ak47") -> {
                // Classic AK-47 "7" pattern
                val vertical = (idx * 0.45f).coerceAtMost(6.5f)
                val horizontal = when (idx) {
                    in 0..5 -> 0.0f
                    in 6..11 -> (idx - 5) * 0.8f // kick right
                    in 12..19 -> 4.8f - ((idx - 11) * 1.1f) // sweep left
                    else -> -4.0f + ((idx - 19) * 0.7f) // swing back right
                }
                Pair(horizontal, vertical)
            }
            weaponId.contains("m4a4") -> {
                val vertical = (idx * 0.38f).coerceAtMost(5.5f)
                val horizontal = when (idx) {
                    in 0..7 -> 0.0f
                    in 8..15 -> (idx - 7) * 0.55f
                    else -> 4.4f - ((idx - 15) * 0.6f)
                }
                Pair(horizontal, vertical)
            }
            weaponId.contains("deagle") -> {
                if (idx == 0) Pair(0f, 0f) else Pair(Random.nextFloat() * 4f - 2f, 4.5f)
            }
            else -> Pair(Random.nextFloat() * 2f - 1f, (idx * 0.25f).coerceAtMost(4f))
        }
    }

    fun playerShoot(shooter: PlayerActor, target: PlayerActor, nowMs: Long): ShootResult {
        if (!shooter.isAlive || shooter.isReloading || shooter.ammoInMag <= 0 || shooter.isPlanting || shooter.isDefusing) {
            return ShootResult(false, hit = false, headshot = false, damage = 0, targetKilled = false)
        }

        if (nowMs - lastShootTimestamp < shooter.activeWeapon.fireRateMs) {
            return ShootResult(false, hit = false, headshot = false, damage = 0, targetKilled = false)
        }
        lastShootTimestamp = nowMs

        shooter.ammoInMag--
        shooter.lastBurstTimeMs = nowMs

        // Movement spread penalty (CS:GO inaccuracy while moving)
        val moveSpeed = hypot(shooter.vx, shooter.vy)
        val movementPenalty = (moveSpeed / 3.4f) * 7.5f // large penalty if running
        val crouchBonus = if (shooter.isCrouching) 0.6f else 1.0f

        // Get spray offset for current shot in spray
        val (sprayH, sprayV) = getSprayOffsetDeg(shooter.activeWeapon.id, shooter.burstShotIndex)
        shooter.burstShotIndex++

        // Base spread + recoil accumulation
        val effectiveSpreadDeg = ((shooter.activeWeapon.spread * 50f + movementPenalty) * crouchBonus) +
                (if (shooter.isScoped) 1.0f else 3.5f)

        // Line of sight check (also blocked by active smoke clouds)
        if (isBlockedBySmoke(shooter.x, shooter.y, target.x, target.y)) {
            return ShootResult(fired = true, hit = false, headshot = false, damage = 0, targetKilled = false)
        }

        val dx = target.x - shooter.x
        val dy = target.y - shooter.y
        val angleToTargetDeg = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()

        // Apply recoil to aim angle
        val actualBulletAngle = shooter.angleDeg + sprayH

        var angleDiff = Math.abs(actualBulletAngle - angleToTargetDeg)
        if (angleDiff > 180f) angleDiff = 360f - angleDiff

        val hasHit = angleDiff < effectiveSpreadDeg && hasLineOfSight(shooter.x, shooter.y, target.x, target.y)

        if (hasHit) {
            // Headshot calculation: closer to true center
            val isHeadshot = angleDiff < (effectiveSpreadDeg * 0.32f) || shooter.activeWeapon.id.contains("awp")
            val baseDamage = shooter.activeWeapon.damage

            val rawDamage = if (isHeadshot) {
                // If target has helmet, reduce headshot damage slightly for pistols
                if (target.hasHelmet && shooter.activeWeapon.type == WeaponType.PISTOL) {
                    (baseDamage * 2.8f).toInt()
                } else {
                    baseDamage * 4 // Lethal 1-tap with AK-47 & AWP
                }
            } else {
                // Armor chest damage reduction (CS:GO ~30% armor absorption)
                if (target.armor > 0) {
                    target.armor = (target.armor - (baseDamage * 0.3f).toInt()).coerceAtLeast(0)
                    (baseDamage * 0.75f).toInt()
                } else {
                    baseDamage
                }
            }

            target.health = (target.health - rawDamage).coerceAtLeast(0)
            val killed = target.health <= 0

            var reward = 0
            if (killed) {
                target.isAlive = false
                reward = shooter.activeWeapon.killReward
                shooter.money = (shooter.money + reward).coerceAtMost(16000)

                killFeed.add(
                    CombatFeedItem(
                        killer = shooter.name,
                        victim = target.name,
                        weapon = shooter.activeWeapon.name,
                        isHeadshot = isHeadshot
                    )
                )

                val wonCT = shooter.isCT
                roundOutcome = if (wonCT) RoundOutcome.CT_ELIMINATION else RoundOutcome.T_ELIMINATION
                applyEconomyRoundEnd(wonCT, false)
            }

            return ShootResult(fired = true, hit = true, headshot = isHeadshot, damage = rawDamage, targetKilled = killed, moneyEarned = reward)
        }

        return ShootResult(fired = true, hit = false, headshot = false, damage = 0, targetKilled = false)
    }

    fun isBlockedBySmoke(x0: Float, y0: Float, x1: Float, y1: Float): Boolean {
        for (smoke in smokeClouds) {
            val dist = pointToLineDistance(smoke.x, smoke.y, x0, y0, x1, y1)
            if (dist < 1.4f) return true // smoke obscures vision
        }
        return false
    }

    private fun pointToLineDistance(px: Float, py: Float, x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x2 - x1
        val dy = y2 - y1
        if (dx == 0f && dy == 0f) return hypot(px - x1, py - y1)
        val t = ((px - x1) * dx + (py - y1) * dy) / (dx * dx + dy * dy)
        val clampedT = t.coerceIn(0f, 1f)
        val nearestX = x1 + clampedT * dx
        val nearestY = y1 + clampedT * dy
        return hypot(px - nearestX, py - nearestY)
    }

    fun hasLineOfSight(x0: Float, y0: Float, x1: Float, y1: Float): Boolean {
        val steps = 30
        for (i in 1 until steps) {
            val t = i.toFloat() / steps
            val px = x0 + (x1 - x0) * t
            val py = y0 + (y1 - y0) * t
            if (!canPass(px, py)) return false
        }
        return true
    }

    private var botNextShootMs = 0L

    private fun updateBotAi(deltaSeconds: Float, nowMs: Long) {
        val dx = localPlayer.x - opponent.x
        val dy = localPlayer.y - opponent.y
        val dist = hypot(dx, dy)
        val targetAngle = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()

        opponent.angleDeg = targetAngle

        val los = hasLineOfSight(opponent.x, opponent.y, localPlayer.x, localPlayer.y) &&
                !isBlockedBySmoke(opponent.x, opponent.y, localPlayer.x, localPlayer.y)

        if (los && dist < 9f) {
            // Stop to achieve zero velocity counter-strafe before shooting
            movePlayer(opponent, 0f, 0f, deltaSeconds)

            if (nowMs >= botNextShootMs && opponent.ammoInMag > 0) {
                playerShoot(opponent, localPlayer, nowMs)
                botNextShootMs = nowMs + opponent.activeWeapon.fireRateMs + Random.nextLong(30, 90)
            } else if (opponent.ammoInMag <= 0 && !opponent.isReloading) {
                opponent.isReloading = true
                opponent.reloadTimerMs = opponent.activeWeapon.reloadTimeMs
            }
        } else {
            // Advance towards bomb site or player
            val targetX = if (bomb.isPlanted && opponent.isCT) bomb.x else localPlayer.x
            val targetY = if (bomb.isPlanted && opponent.isCT) bomb.y else localPlayer.y
            val dirX = targetX - opponent.x
            val dirY = targetY - opponent.y
            val len = hypot(dirX, dirY)
            if (len > 0.5f) {
                movePlayer(opponent, dirX / len, dirY / len, deltaSeconds)
            }

            if (opponent.isCT && isNearPlantedBomb(opponent.x, opponent.y)) {
                opponent.isDefusing = true
            }
        }
    }
}
