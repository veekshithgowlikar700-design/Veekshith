package com.example.game.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

class SoundFxManager(private val scope: CoroutineScope) {

    private val sampleRate = 22050

    fun playGunshot(weaponId: String) {
        scope.launch(Dispatchers.Default) {
            when {
                weaponId.contains("awp") -> playAwpShot()
                weaponId.contains("ak47") -> playAkShot()
                weaponId.contains("deagle") -> playDeagleShot()
                weaponId.contains("knife") -> playKnifeSlash()
                else -> playPistolShot()
            }
        }
    }

    fun playHeadshotDink() {
        scope.launch(Dispatchers.Default) {
            // Metallic high-pitched ringing ping (2200 Hz with fast exponential decay)
            val durationMs = 250
            val numSamples = (sampleRate * durationMs) / 1000
            val buffer = ShortArray(numSamples)
            for (i in 0 until numSamples) {
                val t = i.toDouble() / sampleRate
                val decay = Math.exp(-t * 22.0)
                val tone1 = sin(2.0 * PI * 2150.0 * t)
                val tone2 = sin(2.0 * PI * 3240.0 * t) * 0.5
                val sample = ((tone1 + tone2) * decay * 28000).toInt().coerceIn(-32767, 32767)
                buffer[i] = sample.toShort()
            }
            writeAndPlay(buffer)
        }
    }

    fun playBombBeep(urgency: Float) { // 0.0 to 1.0
        scope.launch(Dispatchers.Default) {
            val freq = 1200.0 + (urgency * 600.0)
            val durationMs = (100 - (urgency * 40)).toInt().coerceAtLeast(40)
            val numSamples = (sampleRate * durationMs) / 1000
            val buffer = ShortArray(numSamples)
            for (i in 0 until numSamples) {
                val t = i.toDouble() / sampleRate
                val sample = (sin(2.0 * PI * freq * t) * 22000).toInt().coerceIn(-32767, 32767)
                buffer[i] = sample.toShort()
            }
            writeAndPlay(buffer)
        }
    }

    fun playBombExplosion() {
        scope.launch(Dispatchers.Default) {
            val durationMs = 1200
            val numSamples = (sampleRate * durationMs) / 1000
            val buffer = ShortArray(numSamples)
            for (i in 0 until numSamples) {
                val t = i.toDouble() / sampleRate
                val decay = Math.exp(-t * 2.8)
                val noise = (Random.nextFloat() * 2.0 - 1.0)
                val subBass = sin(2.0 * PI * 48.0 * t) * 0.7
                val sample = ((noise * 0.6 + subBass) * decay * 32000).toInt().coerceIn(-32767, 32767)
                buffer[i] = sample.toShort()
            }
            writeAndPlay(buffer)
        }
    }

    fun playReload() {
        scope.launch(Dispatchers.Default) {
            val durationMs = 180
            val numSamples = (sampleRate * durationMs) / 1000
            val buffer = ShortArray(numSamples)
            for (i in 0 until numSamples) {
                val t = i.toDouble() / sampleRate
                val click = if (i % 600 < 50) 1.0 else 0.0
                val sample = (click * 20000).toInt().coerceIn(-32767, 32767)
                buffer[i] = sample.toShort()
            }
            writeAndPlay(buffer)
        }
    }

    private fun playAkShot() {
        val durationMs = 180
        val numSamples = (sampleRate * durationMs) / 1000
        val buffer = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val decay = Math.exp(-t * 25.0)
            val noise = Random.nextFloat() * 2.0 - 1.0
            val body = sin(2.0 * PI * 130.0 * t) * 0.8
            val sample = ((noise * 0.8 + body) * decay * 31000).toInt().coerceIn(-32767, 32767)
            buffer[i] = sample.toShort()
        }
        writeAndPlay(buffer)
    }

    private fun playAwpShot() {
        val durationMs = 500
        val numSamples = (sampleRate * durationMs) / 1000
        val buffer = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val decay = Math.exp(-t * 8.0)
            val noise = Random.nextFloat() * 2.0 - 1.0
            val bass = sin(2.0 * PI * 65.0 * t) * 1.0
            val sample = ((noise * 0.7 + bass) * decay * 32700).toInt().coerceIn(-32767, 32767)
            buffer[i] = sample.toShort()
        }
        writeAndPlay(buffer)
    }

    private fun playDeagleShot() {
        val durationMs = 240
        val numSamples = (sampleRate * durationMs) / 1000
        val buffer = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val decay = Math.exp(-t * 18.0)
            val noise = Random.nextFloat() * 2.0 - 1.0
            val punch = sin(2.0 * PI * 110.0 * t) * 0.9
            val sample = ((noise * 0.8 + punch) * decay * 30000).toInt().coerceIn(-32767, 32767)
            buffer[i] = sample.toShort()
        }
        writeAndPlay(buffer)
    }

    private fun playPistolShot() {
        val durationMs = 120
        val numSamples = (sampleRate * durationMs) / 1000
        val buffer = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val decay = Math.exp(-t * 32.0)
            val noise = Random.nextFloat() * 2.0 - 1.0
            val sample = (noise * decay * 26000).toInt().coerceIn(-32767, 32767)
            buffer[i] = sample.toShort()
        }
        writeAndPlay(buffer)
    }

    private fun playKnifeSlash() {
        val durationMs = 150
        val numSamples = (sampleRate * durationMs) / 1000
        val buffer = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val whoosh = sin(2.0 * PI * (400.0 - t * 1200.0) * t) * Math.exp(-t * 15.0)
            val sample = (whoosh * 24000).toInt().coerceIn(-32767, 32767)
            buffer[i] = sample.toShort()
        }
        writeAndPlay(buffer)
    }

    private fun writeAndPlay(buffer: ShortArray) {
        try {
            val audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(buffer.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            audioTrack.write(buffer, 0, buffer.size)
            audioTrack.play()
            // release after finish
            audioTrack.setNotificationMarkerPosition(buffer.size)
            audioTrack.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
                override fun onMarkerReached(track: AudioTrack?) {
                    track?.stop()
                    track?.release()
                }
                override fun onPeriodicNotification(track: AudioTrack?) {}
            })
        } catch (_: Exception) {
            // AudioTrack fallback
        }
    }
}
