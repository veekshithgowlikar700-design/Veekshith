package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.GameCatalog
import com.example.ui.StrikeZoneViewModel

@Composable
fun RankedLeaguesScreen(
    viewModel: StrikeZoneViewModel,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val userProfile by viewModel.userProfile.collectAsState()
    val userPoints = userProfile?.rankPoints ?: 1000L
    val currentTier = GameCatalog.getTierForPoints(userPoints)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F1318))
    ) {
        // TOP BAR
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1E2530))
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "RANKED COMPETITIVE LEAGUES",
                color = Color.White,
                fontWeight = FontWeight.Black,
                fontSize = 17.sp,
                letterSpacing = 1.sp
            )
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // CURRENT RANK BADGE CARD
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF19202B)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(2.dp, Color(currentTier.colorHex), RoundedCornerShape(16.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(76.dp)
                                .background(Color(currentTier.colorHex).copy(alpha = 0.2f), CircleShape)
                                .border(3.dp, Color(currentTier.colorHex), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = Color(currentTier.colorHex), modifier = Modifier.size(44.dp))
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = currentTier.name.uppercase(),
                            color = Color(currentTier.colorHex),
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp
                        )

                        Text(
                            text = "$userPoints ELO MMR POINTS",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        val progress = if (currentTier.maxPoints > currentTier.minPoints) {
                            ((userPoints - currentTier.minPoints).toFloat() / (currentTier.maxPoints - currentTier.minPoints)).coerceIn(0f, 1f)
                        } else 1f

                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Promotion Progress", color = Color(0xFF90A4AE), fontSize = 11.sp)
                                Text("${(progress * 100).toInt()}%", color = Color(currentTier.colorHex), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { progress },
                                color = Color(currentTier.colorHex),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                            )
                        }
                    }
                }
            }

            // COMPETITIVE TIERS LADDER
            item {
                Text(
                    text = "COMPETITIVE TIER HIERARCHY",
                    color = Color(0xFF90A4AE),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    letterSpacing = 1.sp
                )
            }

            items(GameCatalog.RANK_TIERS) { tier ->
                val isUserTier = currentTier.name == tier.name
                Surface(
                    color = if (isUserTier) Color(0xFF242E3D) else Color(0xFF141922),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(if (isUserTier) 1.5f.dp else 1.dp, if (isUserTier) Color(tier.colorHex) else Color(0xFF263238), RoundedCornerShape(10.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(Color(tier.colorHex).copy(alpha = 0.2f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.MilitaryTech, contentDescription = null, tint = Color(tier.colorHex), modifier = Modifier.size(22.dp))
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = tier.name,
                                    color = if (isUserTier) Color.White else Color(0xFFECEFF1),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "${tier.minPoints} - ${if (tier.maxPoints >= 99999) "MAX" else tier.maxPoints} MMR",
                                    color = Color(0xFF78909C),
                                    fontSize = 11.sp
                                )
                            }
                        }

                        if (isUserTier) {
                            Surface(
                                color = Color(tier.colorHex),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "YOUR RANK",
                                    color = Color.Black,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
