package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.InventoryItem
import com.example.data.model.MarketplaceListing
import com.example.ui.ScreenState
import com.example.ui.StrikeZoneViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MarketplaceScreen(
    viewModel: StrikeZoneViewModel,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val userProfile by viewModel.userProfile.collectAsState()
    val listings by viewModel.marketplace.collectAsState()
    val inventory by viewModel.inventory.collectAsState()

    var selectedFilter by remember { mutableStateOf("ALL") }
    var showSellSheet by remember { mutableStateOf(false) }

    val categories = listOf("ALL", "KNIVES", "RIFLES", "SNIPERS", "PISTOLS")

    val filteredListings = listings.filter { item ->
        when (selectedFilter) {
            "KNIVES" -> item.weaponName.contains("Knife") || item.weaponName.contains("Bayonet") || item.weaponName.contains("Karambit")
            "RIFLES" -> item.weaponName.contains("AK") || item.weaponName.contains("M4")
            "SNIPERS" -> item.weaponName.contains("AWP")
            "PISTOLS" -> item.weaponName.contains("Deagle") || item.weaponName.contains("Glock") || item.weaponName.contains("USP")
            else -> true
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showSellSheet = true },
                containerColor = Color(0xFFFF9800),
                contentColor = Color.Black,
                modifier = Modifier.testTag("sell_skin_fab")
            ) {
                Row(modifier = Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Add, contentDescription = "Sell Skin")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("SELL SKIN", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0F1318))
                .padding(innerPadding)
        ) {
            // TOP HEADER
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1E2530))
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Text(
                        text = "COMMUNITY MARKET",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        letterSpacing = 1.sp
                    )
                }

                Surface(
                    color = Color(0xFF263238),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.MonetizationOn, contentDescription = "Coins", tint = Color(0xFFFFD54F), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("${userProfile?.coins ?: 0}", color = Color(0xFFFFD54F), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }

            // FILTER TABS
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF141A23))
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { category ->
                    val isSelected = selectedFilter == category
                    Surface(
                        color = if (isSelected) Color(0xFFFF9800) else Color(0xFF242C38),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.clickable { selectedFilter = category }
                    ) {
                        Text(
                            text = category,
                            color = if (isSelected) Color.Black else Color(0xFFECEFF1),
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            // LISTINGS GRID / LIST
            if (filteredListings.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.ShoppingBag, contentDescription = null, tint = Color(0xFF546E7A), modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No active listings in this category", color = Color(0xFF90A4AE), fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Be the first to list a skin from your inventory!", color = Color(0xFF78909C), fontSize = 12.sp)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredListings) { listing ->
                        MarketplaceItemCard(
                            listing = listing,
                            userCoins = userProfile?.coins ?: 0L,
                            onBuy = { viewModel.buySkinFromMarketplace(listing) }
                        )
                    }
                }
            }
        }

        // SELL SKIN BOTTOM SHEET
        if (showSellSheet) {
            ModalBottomSheet(
                onDismissRequest = { showSellSheet = false },
                containerColor = Color(0xFF171D25),
                sheetState = rememberModalBottomSheetState()
            ) {
                SellSkinSheetContent(
                    inventory = inventory,
                    onListSkin = { item, price ->
                        viewModel.listSkinOnMarketplace(item, price)
                        showSellSheet = false
                    },
                    onDismiss = { showSellSheet = false }
                )
            }
        }
    }
}

@Composable
private fun MarketplaceItemCard(
    listing: MarketplaceListing,
    userCoins: Long,
    onBuy: () -> Unit
) {
    val rarityColor = when (listing.rarity) {
        "Rare Special", "Contraband" -> Color(0xFFFFD700)
        "Covert" -> Color(0xFFEB4B4B)
        "Classified" -> Color(0xFFD32CE6)
        "Restricted" -> Color(0xFF8847FF)
        else -> Color(0xFF4B69FF)
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1B222D)),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, rarityColor.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Skin details
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .background(rarityColor.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                        .border(1.dp, rarityColor, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Shield, contentDescription = null, tint = rarityColor, modifier = Modifier.size(28.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (listing.isStatTrak) {
                            Surface(
                                color = Color(0xFFFF9800),
                                shape = RoundedCornerShape(3.dp),
                                modifier = Modifier.padding(end = 4.dp)
                            ) {
                                Text("StatTrak™", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp))
                            }
                        }
                        Text(
                            text = "${listing.weaponName} | ${listing.skinName}",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${listing.wear} • ${listing.rarity}",
                        color = rarityColor,
                        fontSize = 11.sp
                    )
                    Text(
                        text = "Seller: ${listing.sellerName}",
                        color = Color(0xFF78909C),
                        fontSize = 10.sp
                    )
                }
            }

            // Price & Buy Button
            Column(horizontalAlignment = Alignment.End) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = Color(0xFFFFD54F), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${listing.priceCoins}",
                        color = Color(0xFFFFD54F),
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                val canAfford = userCoins >= listing.priceCoins
                Button(
                    onClick = onBuy,
                    enabled = canAfford,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFFF9800),
                        disabledContainerColor = Color(0xFF37474F)
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.height(32.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                ) {
                    Text(if (canAfford) "BUY NOW" else "LOW COINS", fontSize = 11.sp, color = if (canAfford) Color.Black else Color(0xFF90A4AE), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun SellSkinSheetContent(
    inventory: List<InventoryItem>,
    onListSkin: (InventoryItem, Long) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedItem by remember { mutableStateOf<InventoryItem?>(inventory.firstOrNull()) }
    var priceText by remember { mutableStateOf("300") }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp)
    ) {
        Text("LIST SKIN FOR SALE", color = Color(0xFFFF9800), fontWeight = FontWeight.Black, fontSize = 18.sp)
        Text("Select an item from your inventory to put on the community market", color = Color(0xFF90A4AE), fontSize = 12.sp)

        Spacer(modifier = Modifier.height(14.dp))

        if (inventory.isEmpty()) {
            Text("No skins in your inventory! Open cases to get skins.", color = Color(0xFFEF5350), fontSize = 13.sp)
        } else {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(inventory) { item ->
                    val isSelected = selectedItem?.id == item.id
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) Color(0xFF2E3846) else Color(0xFF1E2530)
                        ),
                        modifier = Modifier
                            .width(140.dp)
                            .border(if (isSelected) 2.dp else 1.dp, if (isSelected) Color(0xFFFF9800) else Color(0xFF37474F), RoundedCornerShape(8.dp))
                            .clickable { selectedItem = item }
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("${item.weaponName}", color = Color(0xFF90A4AE), fontSize = 11.sp)
                            Text("${item.skinName}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("${item.wear}", color = Color(0xFFFFB74D), fontSize = 10.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = priceText,
                onValueChange = { priceText = it.filter { char -> char.isDigit() } },
                label = { Text("Price in Coins") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFFFF9800),
                    unfocusedBorderColor = Color(0xFF37474F),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = {
                    val price = priceText.toLongOrNull() ?: 100L
                    selectedItem?.let { item -> onListSkin(item, price) }
                },
                enabled = selectedItem != null && (priceText.toLongOrNull() ?: 0L) > 0L,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9800)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("confirm_listing_button")
            ) {
                Text("POST LISTING TO MARKETPLACE", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}
