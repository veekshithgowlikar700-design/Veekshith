package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = TacticalOrange,
    onPrimary = Color.Black,
    secondary = TacticalAmber,
    onSecondary = Color.Black,
    tertiary = TacticalCyan,
    background = TacticalDark,
    onBackground = Color(0xFFECEFF1),
    surface = TacticalSurface,
    onSurface = Color.White,
    surfaceVariant = Color(0xFF1E2633),
    onSurfaceVariant = Color(0xFFB0BEC5),
    outline = TacticalBorder
)

@Composable
fun StrikeZoneTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
