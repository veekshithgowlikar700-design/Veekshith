package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MapBlueprint
import com.example.ui.StrikeZoneViewModel

enum class ToolTile(val id: Int, val label: String, val color: Color) {
    FLOOR(0, "Floor", Color(0xFF161B22)),
    WALL(1, "Wall", Color(0xFF37474F)),
    CRATE(2, "Crate", Color(0xFF8D6E63)),
    SITE_A(3, "Site A", Color(0xFFFF9800)),
    SITE_B(4, "Site B", Color(0xFFFFC107)),
    SPAWN_T(5, "T Spawn", Color(0xFFE65100)),
    SPAWN_CT(6, "CT Spawn", Color(0xFF1976D2))
}

@Composable
fun MapEditorScreen(
    viewModel: StrikeZoneViewModel,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val gridSize = 14
    var grid by remember {
        val initial = Array(gridSize) { y ->
            IntArray(gridSize) { x ->
                when {
                    x == 0 || x == gridSize - 1 || y == 0 || y == gridSize - 1 -> 1
                    x == 2 && y == 12 -> 5 // T Spawn
                    x == 11 && y == 2 -> 6 // CT Spawn
                    x == 10 && y == 10 -> 3 // Site A
                    x == 3 && y == 3 -> 4 // Site B
                    (x in 4..9 && y == 7) -> 1 // Mid wall
                    else -> 0
                }
            }
        }
        mutableStateOf(initial)
    }

    var selectedTool by remember { mutableStateOf(ToolTile.WALL) }
    var showPublishDialog by remember { mutableStateOf(false) }
    var mapTitle by remember { mutableStateOf("Custom Tactical Arena") }
    var mapDesc by remember { mutableStateOf("Created with StrikeZone built-in map editor") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F1318))
    ) {
        // TOP HEADER
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1E2530))
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "MAP EDITOR",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    letterSpacing = 1.sp
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Clear / Reset
                IconButton(
                    onClick = {
                        grid = Array(gridSize) { y ->
                            IntArray(gridSize) { x ->
                                if (x == 0 || x == gridSize - 1 || y == 0 || y == gridSize - 1) 1 else 0
                            }
                        }
                    }
                ) {
                    Icon(Icons.Default.RestartAlt, contentDescription = "Reset", tint = Color(0xFFEF5350))
                }

                // Publish
                Button(
                    onClick = { showPublishDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9800)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(36.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                ) {
                    Icon(Icons.Default.CloudUpload, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("PUBLISH", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }

        // TOOL SELECTOR PALETTE
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF141A23))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(ToolTile.values()) { tool ->
                val isSelected = selectedTool == tool
                Surface(
                    color = if (isSelected) tool.color else Color(0xFF222B38),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .border(1.dp, tool.color, RoundedCornerShape(8.dp))
                        .clickable { selectedTool = tool }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .background(tool.color, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = tool.label,
                            color = if (isSelected && tool == ToolTile.SITE_A) Color.Black else Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // GRID CANVAS
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(12.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141922)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.border(2.dp, Color(0xFF2E3846), RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    for (y in 0 until gridSize) {
                        Row {
                            for (x in 0 until gridSize) {
                                val tileId = grid[y][x]
                                val tileColor = when (tileId) {
                                    1 -> Color(0xFF37474F)
                                    2 -> Color(0xFF8D6E63)
                                    3 -> Color(0xFFFF9800)
                                    4 -> Color(0xFFFFC107)
                                    5 -> Color(0xFFE65100)
                                    6 -> Color(0xFF1976D2)
                                    else -> Color(0xFF161B22)
                                }

                                Box(
                                    modifier = Modifier
                                        .size(22.dp)
                                        .background(tileColor)
                                        .border(0.5.dp, Color(0x33FFFFFF))
                                        .clickable {
                                            // Update cell
                                            val newGrid = Array(gridSize) { gy ->
                                                IntArray(gridSize) { gx ->
                                                    if (gy == y && gx == x) selectedTool.id else grid[gy][gx]
                                                }
                                            }
                                            grid = newGrid
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (tileId == 3) Text("A", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Black)
                                    if (tileId == 4) Text("B", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Black)
                                    if (tileId == 5) Text("T", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    if (tileId == 6) Text("CT", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // BOTTOM ACTION BAR: TEST PLAY
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Button(
                onClick = {
                    val customMap = MapBlueprint(
                        id = "custom_edited_map",
                        name = "Custom Layout",
                        description = "User created map",
                        width = gridSize,
                        height = gridSize,
                        spawnT = Pair(2, 12),
                        spawnCT = Pair(11, 2),
                        siteA = Pair(10, 10),
                        siteB = Pair(3, 3)
                    )
                    viewModel.startPracticeMatch(customMap)
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("test_map_button")
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
                Spacer(modifier = Modifier.width(8.dp))
                Text("TEST PLAY MAP IN 1v1 MATCH", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 14.sp)
            }
        }

        // PUBLISH DIALOG
        if (showPublishDialog) {
            AlertDialog(
                onDismissRequest = { showPublishDialog = false },
                containerColor = Color(0xFF1E2530),
                title = { Text("Publish Community Map", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = mapTitle,
                            onValueChange = { mapTitle = it },
                            label = { Text("Map Title") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFFFF9800),
                                unfocusedBorderColor = Color(0xFF455A64)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = mapDesc,
                            onValueChange = { mapDesc = it },
                            label = { Text("Description") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFFFF9800),
                                unfocusedBorderColor = Color(0xFF455A64)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val dataBuilder = StringBuilder()
                            for (row in grid) {
                                for (cell in row) {
                                    dataBuilder.append(cell)
                                }
                            }
                            viewModel.publishCustomMap(
                                title = mapTitle,
                                description = mapDesc,
                                gridData = dataBuilder.toString(),
                                width = gridSize.toLong(),
                                height = gridSize.toLong()
                            )
                            showPublishDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9800))
                    ) {
                        Text("UPLOAD & SHARE", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    Button(
                        onClick = { showPublishDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF37474F))
                    ) {
                        Text("CANCEL", color = Color.White)
                    }
                }
            )
        }
    }
}
