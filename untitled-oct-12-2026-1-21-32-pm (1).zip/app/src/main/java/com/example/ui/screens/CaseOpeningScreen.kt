package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.GameCatalog
import com.example.data.model.SkinDef
import com.example.game.audio.SoundFxManager
import com.example.ui.StrikeZoneViewModel
import kotlinx.coroutines.launch
import kotlin.math.roundToInt
import kotlin.random.Random

data class CaseContainer(
    val id: String,
    val name: String,
    val series: String,
    val costCoins: Long = 250L,
    val pool: List<SkinDef>
)

@Composable
fun CaseOpeningScreen(
    viewModel: StrikeZoneViewModel,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val scope = rememberCoroutineScope()
    val soundFx = remember { SoundFxManager(scope) }

    val userProfile by viewModel.userProfile.collectAsState()

    val cases = remember {
        listOf(
            CaseContainer(
                "chroma3",
                "Chroma 3 Case",
                "Special Item: Karambit Doppler & Fade",
                pool = GameCatalog.SKINS
            ),
            CaseContainer(
                "bravo",
                "Operation Bravo Case",
                "Special Item: Fire Serpent & Dragon Lore",
                pool = GameCatalog.SKINS.shuffled()
            ),
            CaseContainer(
                "weapon1",
                "CS:GO Weapon Case #1",
                "Special Item: Case Hardened Blue Gem",
                pool = GameCatalog.SKINS.reversed()
            )
        )
    }

    var selectedCase by remember { mutableStateOf(cases.first()) }
    var isSpinning by remember { mutableStateOf(false) }
    var wonSkin by remember { mutableStateOf<SkinDef?>(null) }
    var showWonDialog by remember { mutableStateOf(false) }

    // Reel items (40 items long)
    val reelItems = remember(selectedCase) {
        val list = mutableListOf<SkinDef>()
        for (i in 0 until 40) {
            list.add(selectedCase.pool.random())
        }
        list
    }

    val reelOffsetAnim = remember { Animatable(0f) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F1318))
    ) {
        // TOP HEADER
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1E2530))
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Text(
                    text = "WEAPON CASE OPENING",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    letterSpacing = 1.sp
                )
            }

            Surface(
                color = Color(0xFF263238),
                shape = RoundedCornerShape(20.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.MonetizationOn, contentDescription = "Coins", tint = Color(0xFFFFD54F), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("${userProfile?.coins ?: 0}", color = Color(0xFFFFD54F), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }

        // CASE SELECTOR TABS
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(cases) { c ->
                val isSelected = selectedCase.id == c.id
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) Color(0xFF2C3848) else Color(0xFF1A212B)
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .width(180.dp)
                        .border(if (isSelected) 2.dp else 1.dp, if (isSelected) Color(0xFFFF9800) else Color(0xFF37474F), RoundedCornerShape(10.dp))
                        .clickable(enabled = !isSpinning) { selectedCase = c }
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFFFF9800), modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(c.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(c.series, color = Color(0xFF90A4AE), fontSize = 10.sp, maxLines = 1)
                    }
                }
            }
        }

        // REEL ROULETTE VIEW
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF141922)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .border(2.dp, Color(0xFF2E3846), RoundedCornerShape(16.dp))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(170.dp)
                    .clip(RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                // Horizontal scrolling reel of skins
                Row(
                    modifier = Modifier
                        .offset { IntOffset(reelOffsetAnim.value.roundToInt(), 0) }
                        .padding(horizontal = 180.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    reelItems.forEach { skin ->
                        SkinReelCard(skin)
                    }
                }

                // Center Needle / Cursor
                Box(
                    modifier = Modifier
                        .width(4.dp)
                        .height(170.dp)
                        .background(Color(0xFFFFD54F))
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // OPEN CASE BUTTON
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val userCoins = userProfile?.coins ?: 0L
            val canAfford = userCoins >= selectedCase.costCoins

            Button(
                onClick = {
                    if (!isSpinning && canAfford) {
                        isSpinning = true
                        val won = viewModel.openCase(selectedCase.name)
                        wonSkin = won

                        scope.launch {
                            // Sound cue
                            soundFx.playReload()
                            reelOffsetAnim.snapTo(0f)
                            // Target index ~ 32
                            val targetOffset = -(32 * 118f) - Random.nextFloat() * 80f
                            reelOffsetAnim.animateTo(
                                targetValue = targetOffset,
                                animationSpec = tween(durationMillis = 4500, easing = FastOutSlowInEasing)
                            )
                            isSpinning = false
                            showWonDialog = true
                            soundFx.playHeadshotDink()
                        }
                    }
                },
                enabled = !isSpinning && canAfford,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFFF9800),
                    disabledContainerColor = Color(0xFF37474F)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("open_case_button")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LockOpen, contentDescription = null, tint = if (canAfford) Color.Black else Color(0xFF90A4AE))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = if (isSpinning) "SPINNING CONTAINER..." else "UNLOCK CASE (250 COINS)",
                        color = if (canAfford) Color.Black else Color(0xFF90A4AE),
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        letterSpacing = 1.sp
                    )
                }
            }

            if (!canAfford) {
                Spacer(modifier = Modifier.height(8.dp))
                Text("Insufficient Coins! Win 1v1 matches to earn coins.", color = Color(0xFFEF5350), fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // POSSIBLE DROPS PREVIEW
        Text(
            text = "POSSIBLE ITEMS IN THIS CASE",
            color = Color(0xFF90A4AE),
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        Spacer(modifier = Modifier.height(8.dp))
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(selectedCase.pool) { skin ->
                SkinDropPill(skin)
            }
        }

        // WON SKIN DIALOG
        if (showWonDialog && wonSkin != null) {
            WonSkinModal(skin = wonSkin!!, onClaim = { showWonDialog = false })
        }
    }
}

@Composable
private fun SkinReelCard(skin: SkinDef) {
    val rarityColor = Color(skin.colorHex)
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1B222D)),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .width(110.dp)
            .height(130.dp)
            .border(2.dp, rarityColor, RoundedCornerShape(8.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Default.Shield, contentDescription = null, tint = rarityColor, modifier = Modifier.size(36.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text(skin.weaponName, color = Color(0xFF90A4AE), fontSize = 10.sp, maxLines = 1)
            Text(skin.skinName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, textAlign = TextAlign.Center, maxLines = 1)
            Text(skin.rarity, color = rarityColor, fontSize = 9.sp)
        }
    }
}

@Composable
private fun SkinDropPill(skin: SkinDef) {
    val rarityColor = Color(skin.colorHex)
    Surface(
        color = Color(0xFF1E2530),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.border(1.dp, rarityColor, RoundedCornerShape(8.dp))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(rarityColor, CircleShape)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text("${skin.weaponName} | ${skin.skinName}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun WonSkinModal(skin: SkinDef, onClaim: () -> Unit) {
    val rarityColor = Color(skin.colorHex)
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xDD000000)),
        contentAlignment = Alignment.Center
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A222C)),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
                .padding(24.dp)
                .fillMaxWidth()
                .border(2.dp, rarityColor, RoundedCornerShape(20.dp))
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("CONGRATULATIONS!", color = Color(0xFFFFD54F), fontWeight = FontWeight.Black, fontSize = 22.sp, letterSpacing = 2.sp)
                Spacer(modifier = Modifier.height(14.dp))
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .background(rarityColor.copy(alpha = 0.2f), CircleShape)
                        .border(3.dp, rarityColor, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Shield, contentDescription = null, tint = rarityColor, modifier = Modifier.size(54.dp))
                }
                Spacer(modifier = Modifier.height(14.dp))
                Text("${skin.weaponName}", color = Color(0xFFB0BEC5), fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text("${skin.skinName}", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                Text("${skin.rarity}", color = rarityColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(8.dp))
                Text(skin.patternDescription, color = Color(0xFF90A4AE), fontSize = 12.sp, textAlign = TextAlign.Center)

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onClaim,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9800)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("claim_skin_button")
                ) {
                    Text("CLAIM TO INVENTORY", color = Color.Black, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}
