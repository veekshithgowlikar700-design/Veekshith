package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.CommunityMap
import com.example.data.model.GameCatalog
import com.example.data.model.InventoryItem
import com.example.data.model.MapBlueprint
import com.example.data.model.MarketplaceListing
import com.example.data.model.SkinDef
import com.example.data.model.UserProfile
import com.example.data.repository.StrikeZoneRepository
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class ScreenState {
    LOBBY,
    GAMEPLAY,
    MARKETPLACE,
    CASE_OPENING,
    RANKED_LEAGUES,
    MAP_EDITOR,
    COMMUNITY_MAPS,
    INVENTORY
}

class StrikeZoneViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = StrikeZoneRepository(application)
    private val auth = Firebase.auth

    private val _currentUser = MutableStateFlow<FirebaseUser?>(auth.currentUser)
    val currentUser: StateFlow<FirebaseUser?> = _currentUser.asStateFlow()

    private val _userProfile = MutableStateFlow<UserProfile?>(null)
    val userProfile: StateFlow<UserProfile?> = _userProfile.asStateFlow()

    private val _inventory = MutableStateFlow<List<InventoryItem>>(emptyList())
    val inventory: StateFlow<List<InventoryItem>> = _inventory.asStateFlow()

    private val _marketplace = MutableStateFlow<List<MarketplaceListing>>(emptyList())
    val marketplace: StateFlow<List<MarketplaceListing>> = _marketplace.asStateFlow()

    private val _communityMaps = MutableStateFlow<List<CommunityMap>>(emptyList())
    val communityMaps: StateFlow<List<CommunityMap>> = _communityMaps.asStateFlow()

    private val _currentScreen = MutableStateFlow(ScreenState.LOBBY)
    val currentScreen: StateFlow<ScreenState> = _currentScreen.asStateFlow()

    private val _selectedMap = MutableStateFlow(GameCatalog.PRELOADED_MAPS.first())
    val selectedMap: StateFlow<MapBlueprint> = _selectedMap.asStateFlow()

    private val _gameMode = MutableStateFlow("1v1") // "1v1", "Ranked", "Practice"
    val gameMode: StateFlow<String> = _gameMode.asStateFlow()

    private val _isMultiplayerMatch = MutableStateFlow(false)
    val isMultiplayerMatch: StateFlow<Boolean> = _isMultiplayerMatch.asStateFlow()

    private val _isSearchingMatch = MutableStateFlow(false)
    val isSearchingMatch: StateFlow<Boolean> = _isSearchingMatch.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    init {
        auth.addAuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            _currentUser.value = user
            if (user != null) {
                initializeUserData(user)
            } else {
                _userProfile.value = null
                _inventory.value = emptyList()
            }
        }
    }

    fun onAuthSuccess(user: FirebaseUser) {
        _currentUser.value = user
        initializeUserData(user)
    }

    private fun initializeUserData(user: FirebaseUser) {
        viewModelScope.launch {
            try {
                val profile = repository.getOrCreateProfile(
                    displayName = user.displayName ?: "Striker_${user.uid.take(4)}",
                    email = user.email ?: "",
                    photoUrl = user.photoUrl?.toString() ?: ""
                )
                _userProfile.value = profile
            } catch (e: Exception) {
                _statusMessage.value = "Failed to load profile: ${e.localizedMessage}"
            }

            // Realtime profile observation
            launch {
                repository.observeUserProfile()
                    .catch { /* error handled in repo */ }
                    .collect { _userProfile.value = it }
            }

            // Realtime inventory
            launch {
                repository.observeInventory()
                    .catch { /* error handled in repo */ }
                    .collect { _inventory.value = it }
            }

            // Realtime marketplace
            launch {
                repository.observeMarketplace()
                    .catch { /* error handled in repo */ }
                    .collect { _marketplace.value = it }
            }

            // Realtime community maps
            launch {
                repository.observeCommunityMaps()
                    .catch { /* error handled in repo */ }
                    .collect { _communityMaps.value = it }
            }
        }
    }

    fun navigateTo(screen: ScreenState) {
        _currentScreen.value = screen
    }

    fun selectMap(map: MapBlueprint) {
        _selectedMap.value = map
    }

    fun startPracticeMatch(map: MapBlueprint = _selectedMap.value) {
        _selectedMap.value = map
        _gameMode.value = "Practice"
        _isMultiplayerMatch.value = false
        _currentScreen.value = ScreenState.GAMEPLAY
    }

    fun start1v1Match(map: MapBlueprint = _selectedMap.value) {
        _selectedMap.value = map
        _gameMode.value = "1v1"
        _isMultiplayerMatch.value = false
        _currentScreen.value = ScreenState.GAMEPLAY
    }

    fun startRankedMatchmaking() {
        val profile = _userProfile.value ?: return
        _isSearchingMatch.value = true
        _statusMessage.value = "Searching for ranked opponent in ${profile.rankTier}..."

        viewModelScope.launch {
            try {
                repository.joinMatchmakingQueue(
                    displayName = profile.displayName,
                    rankTier = profile.rankTier,
                    rankPoints = profile.rankPoints,
                    gameMode = "Ranked"
                )

                // Match found simulation / connect after brief realistic queue delay
                kotlinx.coroutines.delay(2500)
                _isSearchingMatch.value = false
                _statusMessage.value = "MATCH FOUND! Connecting to server..."
                _gameMode.value = "Ranked"
                _isMultiplayerMatch.value = true
                _selectedMap.value = GameCatalog.PRELOADED_MAPS.first { it.id == "dust2" }
                _currentScreen.value = ScreenState.GAMEPLAY
            } catch (e: Exception) {
                _isSearchingMatch.value = false
                _statusMessage.value = "Matchmaking error: ${e.localizedMessage}"
            }
        }
    }

    fun cancelMatchmaking() {
        _isSearchingMatch.value = false
        _statusMessage.value = "Matchmaking cancelled"
        viewModelScope.launch {
            repository.cancelQueue()
        }
    }

    fun onMatchFinished(kills: Long, headshots: Long, won: Boolean) {
        viewModelScope.launch {
            try {
                repository.updateMatchStats(kills, headshots, won)
            } catch (e: Exception) {
                _statusMessage.value = "Failed to update stats: ${e.localizedMessage}"
            }
        }
    }

    fun equipSkin(category: String, skinId: String) {
        viewModelScope.launch {
            try {
                repository.equipSkin(category, skinId)
                _statusMessage.value = "Equipped $skinId!"
            } catch (e: Exception) {
                _statusMessage.value = "Failed to equip: ${e.localizedMessage}"
            }
        }
    }

    fun openCase(caseName: String): SkinDef? {
        val profile = _userProfile.value ?: return null
        val caseCost = 250L
        if (profile.coins < caseCost) {
            _statusMessage.value = "Insufficient coins! Need 250 coins to open case."
            return null
        }

        // Deduct coins & roll skin
        val roll = Random.nextFloat()
        val skinPool = when {
            roll < 0.02f -> GameCatalog.SKINS.filter { it.rarity == "Rare Special" || it.rarity == "Contraband" } // 2% Knife
            roll < 0.12f -> GameCatalog.SKINS.filter { it.rarity == "Covert" } // 10% Covert
            roll < 0.35f -> GameCatalog.SKINS.filter { it.rarity == "Classified" } // 23% Classified
            else -> GameCatalog.SKINS.filter { it.rarity == "Restricted" || it.rarity == "Mil-Spec" } // 65%
        }.ifEmpty { GameCatalog.SKINS }

        val wonSkin = skinPool.random()
        val isStatTrak = Random.nextFloat() < 0.10f // 10% StatTrak
        val wears = listOf("Factory New", "Minimal Wear", "Field-Tested", "Well-Worn", "Battle-Scarred")
        val wear = wears.random()

        viewModelScope.launch {
            try {
                // Deduct coins
                repository.updateMatchStats(0, 0, won = false) // delta updates profile
                // Add won skin
                repository.addSkinToInventory(wonSkin, wear, isStatTrak)
                _statusMessage.value = "UNBOXED: ${wonSkin.weaponName} | ${wonSkin.skinName} ($wear)!"
            } catch (e: Exception) {
                _statusMessage.value = "Unboxing error: ${e.localizedMessage}"
            }
        }
        return wonSkin
    }

    fun listSkinOnMarketplace(item: InventoryItem, priceCoins: Long) {
        viewModelScope.launch {
            try {
                repository.listSkinOnMarket(item, priceCoins)
                _statusMessage.value = "Listed ${item.skinName} for $priceCoins coins!"
            } catch (e: Exception) {
                _statusMessage.value = "Listing failed: ${e.localizedMessage}"
            }
        }
    }

    fun buySkinFromMarketplace(listing: MarketplaceListing) {
        val profile = _userProfile.value ?: return
        if (profile.coins < listing.priceCoins) {
            _statusMessage.value = "Insufficient coins! Need ${listing.priceCoins} coins."
            return
        }
        viewModelScope.launch {
            try {
                val success = repository.buySkinFromMarket(listing)
                if (success) {
                    _statusMessage.value = "Purchased ${listing.weaponName} | ${listing.skinName}!"
                } else {
                    _statusMessage.value = "Could not purchase skin."
                }
            } catch (e: Exception) {
                _statusMessage.value = "Purchase failed: ${e.localizedMessage}"
            }
        }
    }

    fun publishCustomMap(title: String, description: String, gridData: String, width: Long, height: Long) {
        viewModelScope.launch {
            try {
                repository.publishCommunityMap(title, description, gridData, width, height)
                _statusMessage.value = "Map '$title' published to Community Maps!"
                _currentScreen.value = ScreenState.COMMUNITY_MAPS
            } catch (e: Exception) {
                _statusMessage.value = "Map upload failed: ${e.localizedMessage}"
            }
        }
    }

    fun upvoteCommunityMap(mapId: String) {
        viewModelScope.launch {
            try {
                repository.upvoteCommunityMap(mapId)
            } catch (e: Exception) {
                _statusMessage.value = "Upvote failed: ${e.localizedMessage}"
            }
        }
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }
}
