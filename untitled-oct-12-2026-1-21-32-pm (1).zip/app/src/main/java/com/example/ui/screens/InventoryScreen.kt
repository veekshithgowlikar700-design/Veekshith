package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.InventoryItem
import com.example.ui.ScreenState
import com.example.ui.StrikeZoneViewModel

@Composable
fun InventoryScreen(
    viewModel: StrikeZoneViewModel,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val userProfile by viewModel.userProfile.collectAsState()
    val inventory by viewModel.inventory.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F1318))
    ) {
        // TOP HEADER
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1E2530))
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "WEAPON INVENTORY & LOADOUT",
                color = Color.White,
                fontWeight = FontWeight.Black,
                fontSize = 17.sp,
                letterSpacing = 1.sp
            )
        }

        if (inventory.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Shield, contentDescription = null, tint = Color(0xFF546E7A), modifier = Modifier.size(54.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Your inventory is empty", color = Color(0xFF90A4AE), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Open Cases or visit the Marketplace to acquire weapon skins!", color = Color(0xFF78909C), fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(inventory) { item ->
                    val isEquipped = when {
                        item.weaponName.contains("Knife") || item.weaponName.contains("Bayonet") || item.weaponName.contains("Karambit") ->
                            userProfile?.equippedKnife == item.skinId
                        item.weaponName.contains("AK") || item.weaponName.contains("M4") ->
                            userProfile?.equippedRifle == item.skinId
                        item.weaponName.contains("AWP") ->
                            userProfile?.equippedSniper == item.skinId
                        else ->
                            userProfile?.equippedPistol == item.skinId
                    }

                    InventoryItemCard(
                        item = item,
                        isEquipped = isEquipped,
                        onEquip = {
                            val category = when {
                                item.weaponName.contains("Knife") || item.weaponName.contains("Bayonet") || item.weaponName.contains("Karambit") -> "knife"
                                item.weaponName.contains("AWP") -> "sniper"
                                item.weaponName.contains("AK") || item.weaponName.contains("M4") -> "rifle"
                                else -> "pistol"
                            }
                            viewModel.equipSkin(category, item.skinId)
                        },
                        onSell = {
                            viewModel.navigateTo(ScreenState.MARKETPLACE)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun InventoryItemCard(
    item: InventoryItem,
    isEquipped: Boolean,
    onEquip: () -> Unit,
    onSell: () -> Unit
) {
    val rarityColor = when (item.rarity) {
        "Rare Special", "Contraband" -> Color(0xFFFFD700)
        "Covert" -> Color(0xFFEB4B4B)
        "Classified" -> Color(0xFFD32CE6)
        "Restricted" -> Color(0xFF8847FF)
        else -> Color(0xFF4B69FF)
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1B222D)),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(if (isEquipped) 2.dp else 1.dp, if (isEquipped) Color(0xFFFF9800) else rarityColor.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .background(rarityColor.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                        .border(1.dp, rarityColor, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Shield, contentDescription = null, tint = rarityColor, modifier = Modifier.size(28.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (item.isStatTrak) {
                            Surface(
                                color = Color(0xFFFF9800),
                                shape = RoundedCornerShape(3.dp),
                                modifier = Modifier.padding(end = 4.dp)
                            ) {
                                Text("StatTrak™", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp))
                            }
                        }
                        Text("${item.weaponName} | ${item.skinName}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Text("${item.wear} • ${item.rarity}", color = rarityColor, fontSize = 11.sp)
                    if (item.isStatTrak) {
                        Text("Confirmed Kills: ${item.killsCount}", color = Color(0xFFFF9800), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = onEquip,
                    enabled = !isEquipped,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFFF9800),
                        disabledContainerColor = Color(0xFF263238)
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.height(34.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 0.dp)
                ) {
                    if (isEquipped) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF4CAF50), modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("EQUIPPED", color = Color(0xFF4CAF50), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    } else {
                        Text("EQUIP", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
