package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.GameCatalog
import com.example.data.model.MapBlueprint
import com.example.data.model.WeaponArchetype
import com.example.data.model.WeaponType
import com.example.game.audio.SoundFxManager
import com.example.game.engine.PlayerActor
import com.example.game.engine.RoundOutcome
import com.example.game.engine.TacticalCombatEngine
import com.example.ui.StrikeZoneViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlin.math.sin

data class BulletTracer(
    val x0: Float,
    val y0: Float,
    val x1: Float,
    val y1: Float,
    val timestampMs: Long
)

@Composable
fun GamePlayScreen(
    viewModel: StrikeZoneViewModel,
    map: MapBlueprint,
    isMultiplayer: Boolean,
    onExit: () -> Unit
) {
    BackHandler { onExit() }

    val scope = rememberCoroutineScope()
    val soundFx = remember { SoundFxManager(scope) }

    val engine = remember(map) { TacticalCombatEngine(map, isMultiplayer) }

    // Timing and ticker
    var lastNanos by remember { mutableLongStateOf(0L) }
    var frameTicker by remember { mutableLongStateOf(0L) }

    // Controls state
    var joystickDeltaX by remember { mutableFloatStateOf(0f) }
    var joystickDeltaY by remember { mutableFloatStateOf(0f) }
    var isFiringHeld by remember { mutableStateOf(false) }

    val tracers = remember { mutableStateListOf<BulletTracer>() }
    var showMatchEndDialog by remember { mutableStateOf(false) }
    var matchOutcomeWon by remember { mutableStateOf(false) }
    var showBuyMenu by remember { mutableStateOf(false) }

    // 60 FPS Game Loop
    LaunchedEffect(Unit) {
        while (true) {
            withFrameNanos { nowNanos ->
                if (lastNanos != 0L) {
                    val deltaSeconds = ((nowNanos - lastNanos) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
                    val nowMs = System.currentTimeMillis()

                    // Precise counter-strafing movement
                    engine.movePlayer(engine.localPlayer, joystickDeltaX, joystickDeltaY, deltaSeconds)

                    // Auto-fire while holding fire button
                    if (isFiringHeld) {
                        val result = engine.playerShoot(engine.localPlayer, engine.opponent, nowMs)
                        if (result.fired) {
                            soundFx.playGunshot(engine.localPlayer.activeWeapon.id)
                            tracers.add(
                                BulletTracer(
                                    engine.localPlayer.x, engine.localPlayer.y,
                                    if (result.hit) engine.opponent.x else engine.localPlayer.x + cos(Math.toRadians(engine.localPlayer.angleDeg.toDouble())).toFloat() * 10f,
                                    if (result.hit) engine.opponent.y else engine.localPlayer.y + sin(Math.toRadians(engine.localPlayer.angleDeg.toDouble())).toFloat() * 10f,
                                    nowMs
                                )
                            )
                            if (result.hit && result.headshot) {
                                soundFx.playHeadshotDink()
                            }
                        }
                    }

                    // Engine update
                    engine.update(deltaSeconds, nowMs)

                    // Clean expired tracers
                    tracers.removeAll { nowMs - it.timestampMs > 100L }

                    // Bomb ticking audio
                    if (engine.bomb.isPlanted && !engine.bomb.isDefused && !engine.bomb.isDetonated) {
                        if (frameTicker % 30L == 0L) {
                            val urgency = 1f - (engine.bomb.timerSeconds / 40f).coerceIn(0f, 1f)
                            soundFx.playBombBeep(urgency)
                        }
                    }

                    // Round outcome handling
                    if (engine.roundOutcome != RoundOutcome.IN_PROGRESS && !showMatchEndDialog) {
                        if (engine.currentRound >= engine.maxRounds || engine.ctScore >= 3 || engine.tScore >= 3) {
                            showMatchEndDialog = true
                            matchOutcomeWon = engine.ctScore > engine.tScore
                            viewModel.onMatchFinished(
                                kills = if (matchOutcomeWon) 5L else 2L,
                                headshots = 2L,
                                won = matchOutcomeWon
                            )
                        } else {
                            scope.launch {
                                delay(2800)
                                engine.currentRound++
                                engine.resetRound()
                            }
                        }
                    }

                    frameTicker++
                }
                lastNanos = nowNanos
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0D1117))
    ) {
        // TACTICAL COMBAT CANVAS
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectDragGestures { change, _ ->
                        val centerW = size.width / 2f
                        val centerH = size.height / 2f
                        val angle = Math.toDegrees(atan2((change.position.y - centerH).toDouble(), (change.position.x - centerW).toDouble())).toFloat()
                        engine.localPlayer.angleDeg = angle
                    }
                }
        ) {
            val tileSize = (size.width / (engine.map.width + 2)).coerceAtLeast(18f)
            val cameraOffsetX = size.width / 2f - engine.localPlayer.x * tileSize
            val cameraOffsetY = size.height / 2f - engine.localPlayer.y * tileSize

            // Draw Tiles
            for (y in 0 until engine.map.height) {
                for (x in 0 until engine.map.width) {
                    val px = cameraOffsetX + x * tileSize
                    val py = cameraOffsetY + y * tileSize
                    when (engine.grid[y][x]) {
                        1 -> { // Wall
                            drawRect(Color(0xFF21262D), topLeft = Offset(px, py), size = Size(tileSize, tileSize))
                            drawRect(Color(0xFF30363D), topLeft = Offset(px, py), size = Size(tileSize, tileSize), style = Stroke(1.5f))
                        }
                        2 -> { // Crate
                            drawRect(Color(0xFF8D6E63), topLeft = Offset(px + 2, py + 2), size = Size(tileSize - 4, tileSize - 4))
                            drawRect(Color(0xFF5D4037), topLeft = Offset(px + 2, py + 2), size = Size(tileSize - 4, tileSize - 4), style = Stroke(1.5f))
                        }
                        3 -> { // Bombsite A
                            drawRect(Color(0x33FF9800), topLeft = Offset(px, py), size = Size(tileSize, tileSize))
                            drawRect(Color(0xFFFF9800), topLeft = Offset(px, py), size = Size(tileSize, tileSize), style = Stroke(1f))
                        }
                        4 -> { // Bombsite B
                            drawRect(Color(0x33FFC107), topLeft = Offset(px, py), size = Size(tileSize, tileSize))
                            drawRect(Color(0xFFFFC107), topLeft = Offset(px, py), size = Size(tileSize, tileSize), style = Stroke(1f))
                        }
                        else -> { // Floor
                            drawRect(Color(0xFF161B22), topLeft = Offset(px, py), size = Size(tileSize, tileSize))
                            drawRect(Color(0x11FFFFFF), topLeft = Offset(px, py), size = Size(tileSize, tileSize), style = Stroke(0.5f))
                        }
                    }
                }
            }

            // Draw Smoke Clouds
            for (smoke in engine.smokeClouds) {
                val sx = cameraOffsetX + smoke.x * tileSize
                val sy = cameraOffsetY + smoke.y * tileSize
                val cloudRadius = tileSize * 2.2f
                drawCircle(Color(0xBB424242), radius = cloudRadius, center = Offset(sx, sy))
                drawCircle(Color(0x55616161), radius = cloudRadius * 1.15f, center = Offset(sx, sy))
            }

            // Draw Planted C4
            if (engine.bomb.isPlanted && !engine.bomb.isDefused && !engine.bomb.isDetonated) {
                val bx = cameraOffsetX + engine.bomb.x * tileSize
                val by = cameraOffsetY + engine.bomb.y * tileSize
                val pulseRadius = 16f + (sin(frameTicker * 0.2f) * 6f)
                drawCircle(Color(0x44FF1744), radius = pulseRadius, center = Offset(bx, by))
                drawCircle(Color(0xFFFF1744), radius = 6f, center = Offset(bx, by))
            }

            // Draw Tracers
            for (tracer in tracers) {
                val x0 = cameraOffsetX + tracer.x0 * tileSize
                val y0 = cameraOffsetY + tracer.y0 * tileSize
                val x1 = cameraOffsetX + tracer.x1 * tileSize
                val y1 = cameraOffsetY + tracer.y1 * tileSize
                drawLine(Color(0xFFFFEE58), start = Offset(x0, y0), end = Offset(x1, y1), strokeWidth = 3f)
            }

            // Draw Opponent
            if (engine.opponent.isAlive) {
                val ox = cameraOffsetX + engine.opponent.x * tileSize
                val oy = cameraOffsetY + engine.opponent.y * tileSize
                drawActor(engine.opponent, ox, oy, tileSize)
            }

            // Draw Local Player
            if (engine.localPlayer.isAlive) {
                val lx = cameraOffsetX + engine.localPlayer.x * tileSize
                val ly = cameraOffsetY + engine.localPlayer.y * tileSize
                drawActor(engine.localPlayer, lx, ly, tileSize)
            }

            // Sniper Scope Overlay
            if (engine.localPlayer.isScoped) {
                drawRect(Color(0xCC000000), topLeft = Offset.Zero, size = size)
                val cx = size.width / 2f
                val cy = size.height / 2f
                val radius = size.width * 0.44f
                drawCircle(Color(0x00000000), radius = radius, center = Offset(cx, cy))
                drawCircle(Color(0xFF00E676), radius = radius, center = Offset(cx, cy), style = Stroke(2f))
                drawLine(Color(0xFF00E676), start = Offset(cx - radius, cy), end = Offset(cx + radius, cy), strokeWidth = 1.5f)
                drawLine(Color(0xFF00E676), start = Offset(cx, cy - radius), end = Offset(cx, cy + radius), strokeWidth = 1.5f)
            }
        }

        // FULL SCREEN WHITE FLASH OVERLAY (Flashbang effect)
        if (engine.localPlayer.flashDurationSeconds > 0f) {
            val alpha = (engine.localPlayer.flashDurationSeconds / 4.0f).coerceIn(0f, 0.95f)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.White.copy(alpha = alpha))
            )
        }

        // TOP HUD: Scores, Round Timer, Cash Balance, Buy Button, Kill feed
        TopCombatHudWithEconomy(
            engine = engine,
            onOpenBuyMenu = { showBuyMenu = true },
            onExit = onExit
        )

        // BOTTOM TACTICAL CONTROLS (Movement, Crouch, Grenades, Weapon Switch, Fire)
        BottomTacticalControls(
            engine = engine,
            soundFx = soundFx,
            onJoystickMove = { dx, dy ->
                joystickDeltaX = dx
                joystickDeltaY = dy
            },
            onFireStateChange = { firing ->
                isFiringHeld = firing
            },
            onReload = {
                if (!engine.localPlayer.isReloading && engine.localPlayer.ammoInMag < engine.localPlayer.activeWeapon.magSize) {
                    engine.localPlayer.isReloading = true
                    engine.localPlayer.reloadTimerMs = engine.localPlayer.activeWeapon.reloadTimeMs
                    soundFx.playReload()
                }
            },
            onPlantOrDefuse = {
                if (engine.localPlayer.isCT && engine.isNearPlantedBomb(engine.localPlayer.x, engine.localPlayer.y)) {
                    engine.localPlayer.isDefusing = true
                } else if (!engine.localPlayer.isCT && engine.isAtBombSite(engine.localPlayer.x, engine.localPlayer.y)) {
                    engine.localPlayer.isPlanting = true
                }
            }
        )

        // IN-GAME BUY MENU MODAL
        if (showBuyMenu) {
            InGameBuyMenuDialog(
                player = engine.localPlayer,
                onBuyItem = { cost, action ->
                    if (engine.localPlayer.money >= cost) {
                        engine.localPlayer.money -= cost
                        action()
                        soundFx.playReload()
                    }
                },
                onDismiss = { showBuyMenu = false }
            )
        }

        // MATCH CONCLUSION MODAL
        if (showMatchEndDialog) {
            MatchConclusionDialog(
                won = matchOutcomeWon,
                ctScore = engine.ctScore,
                tScore = engine.tScore,
                onDismiss = onExit
            )
        }
    }
}

private fun DrawScope.drawActor(actor: PlayerActor, px: Float, py: Float, tileSize: Float) {
    val radius = if (actor.isCrouching) tileSize * 0.35f else tileSize * 0.42f
    val rad = Math.toRadians(actor.angleDeg.toDouble())
    val dirX = cos(rad).toFloat()
    val dirY = sin(rad).toFloat()

    // Vision cone
    val coneDist = tileSize * 2.5f
    val color = if (actor.isCT) Color(0x332196F3) else Color(0x33FF9800)
    drawLine(color, start = Offset(px, py), end = Offset(px + cos(rad - 0.4).toFloat() * coneDist, py + sin(rad - 0.4).toFloat() * coneDist), strokeWidth = 1f)
    drawLine(color, start = Offset(px, py), end = Offset(px + cos(rad + 0.4).toFloat() * coneDist, py + sin(rad + 0.4).toFloat() * coneDist), strokeWidth = 1f)

    // Player Body Circle
    val bodyColor = if (actor.isCT) Color(0xFF1E88E5) else Color(0xFFFB8C00)
    drawCircle(bodyColor, radius = radius, center = Offset(px, py))
    drawCircle(Color.White, radius = radius, center = Offset(px, py), style = Stroke(1.5f))

    // Barrel
    val barrelLength = radius * 1.8f
    drawLine(Color(0xFF37474F), start = Offset(px, py), end = Offset(px + dirX * barrelLength, py + dirY * barrelLength), strokeWidth = 4.5f)

    // Health bar above head
    val barW = radius * 2.2f
    val barH = 4f
    val barX = px - barW / 2f
    val barY = py - radius - 10f
    drawRect(Color(0xFFD32F2F), topLeft = Offset(barX, barY), size = Size(barW, barH))
    drawRect(Color(0xFF4CAF50), topLeft = Offset(barX, barY), size = Size(barW * (actor.health / 100f), barH))
}

@Composable
private fun TopCombatHudWithEconomy(
    engine: TacticalCombatEngine,
    onOpenBuyMenu: () -> Unit,
    onExit: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = onExit,
                modifier = Modifier
                    .size(36.dp)
                    .background(Color(0x99000000), CircleShape)
            ) {
                Icon(Icons.Default.Close, contentDescription = "Exit", tint = Color.White)
            }

            // Score & Timer Center Widget
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xDD1B222D)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("CT ${engine.ctScore}", color = Color(0xFF42A5F5), fontWeight = FontWeight.Black, fontSize = 15.sp)
                    Spacer(modifier = Modifier.width(12.dp))
                    Box(
                        modifier = Modifier
                            .background(
                                if (engine.bomb.isPlanted) Color(0xFFD32F2F) else Color(0xFF263238),
                                RoundedCornerShape(6.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (engine.bomb.isPlanted) "C4 ${engine.bomb.timerSeconds.toInt()}s" else "${(engine.roundTimeSeconds / 60).toInt()}:${(engine.roundTimeSeconds % 60).toInt().toString().padStart(2, '0')}",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("${engine.tScore} T", color = Color(0xFFFFB74D), fontWeight = FontWeight.Black, fontSize = 15.sp)
                }
            }

            // Buy Menu Button & In-Game Cash ($)
            Surface(
                color = Color(0xDD1B222D),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.clickable { onOpenBuyMenu() }.testTag("buy_menu_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = Color(0xFF4CAF50), modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "$${engine.localPlayer.money}",
                        color = Color(0xFF4CAF50),
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "[BUY]",
                        color = Color(0xFFFF9800),
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Kill Feed
        if (engine.killFeed.isNotEmpty()) {
            Spacer(modifier = Modifier.height(6.dp))
            Column(
                horizontalAlignment = Alignment.End,
                modifier = Modifier.fillMaxWidth()
            ) {
                engine.killFeed.takeLast(2).forEach { item ->
                    Surface(
                        color = Color(0xCC10141D),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.padding(vertical = 2.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(item.killer, color = Color(0xFF64B5F6), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("[${item.weapon}${if (item.isHeadshot) " 🎯" else ""}]", color = Color(0xFFFFB74D), fontSize = 10.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(item.victim, color = Color(0xFFE57373), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomTacticalControls(
    engine: TacticalCombatEngine,
    soundFx: SoundFxManager,
    onJoystickMove: (Float, Float) -> Unit,
    onFireStateChange: (Boolean) -> Unit,
    onReload: () -> Unit,
    onPlantOrDefuse: () -> Unit
) {
    val player = engine.localPlayer

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Bottom
    ) {
        // PLANT / DEFUSE PROGRESS
        if (player.isPlanting || player.isDefusing) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xDD000000)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (player.isPlanting) "PLANTING C4 BOMB..." else "DEFUSING C4 BOMB...",
                        color = if (player.isPlanting) Color(0xFFFF9800) else Color(0xFF42A5F5),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { player.plantDefuseProgress },
                        color = if (player.isPlanting) Color(0xFFFF9800) else Color(0xFF42A5F5),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // HEALTH, ARMOR, HELMET, DEFUSE KIT, AMMO
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Health
                Surface(
                    color = Color(0xCC1B222D),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Emergency, contentDescription = "Health", tint = Color(0xFFF44336), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("${player.health}", color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp)
                    }
                }
                Spacer(modifier = Modifier.width(6.dp))
                // Armor
                Surface(
                    color = Color(0xCC1B222D),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Security, contentDescription = "Armor", tint = Color(0xFF2196F3), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("${player.armor}${if (player.hasHelmet) " 🪖" else ""}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
                if (player.hasDefuseKit) {
                    Spacer(modifier = Modifier.width(4.dp))
                    Surface(color = Color(0xFF1B5E20), shape = RoundedCornerShape(4.dp)) {
                        Text("KIT", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                    }
                }
            }

            // Weapon & Ammo
            Surface(
                color = Color(0xCC1B222D),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${player.activeWeapon.name.uppercase()} ",
                        color = Color(0xFFFFB74D),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "${player.ammoInMag}/${player.reserveAmmo}",
                        color = if (player.ammoInMag <= 5) Color(0xFFF44336) else Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // GRENADE UTILITY & CROUCH / WALK BAR
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Crouch Button (Halves spread, smaller hitbox)
            Surface(
                color = if (player.isCrouching) Color(0xFFFF9800) else Color(0xCC263238),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(32.dp)
                    .clickable { player.isCrouching = !player.isCrouching }
                    .testTag("crouch_button")
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("CROUCH", color = if (player.isCrouching) Color.Black else Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Walk / Shift (Silent Counter-Strafe)
            Surface(
                color = if (player.isWalking) Color(0xFF42A5F5) else Color(0xCC263238),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(32.dp)
                    .clickable { player.isWalking = !player.isWalking }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("WALK", color = if (player.isWalking) Color.Black else Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Smoke Grenade
            Surface(
                color = if (player.smokeCount > 0) Color(0xFF546E7A) else Color(0x55263238),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(32.dp)
                    .clickable(enabled = player.smokeCount > 0) {
                        engine.throwGrenade(player, "smoke")
                    }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("SMOKE (${player.smokeCount})", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Flashbang
            Surface(
                color = if (player.flashCount > 0) Color(0xFFFFA000) else Color(0x55263238),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(32.dp)
                    .clickable(enabled = player.flashCount > 0) {
                        engine.throwGrenade(player, "flash")
                    }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("FLASH (${player.flashCount})", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }

            // HE Grenade
            Surface(
                color = if (player.heCount > 0) Color(0xFFD32F2F) else Color(0x55263238),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(32.dp)
                    .clickable(enabled = player.heCount > 0) {
                        engine.throwGrenade(player, "he")
                    }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("HE (${player.heCount})", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // DUAL VIRTUAL JOYSTICK & ACTION BUTTONS
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            // LEFT: Virtual Joystick (Movement)
            VirtualJoystick(onMove = onJoystickMove)

            // RIGHT: Action Cluster (Reload, Scope, Plant/Defuse, Fire)
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Reload Button
                    IconButton(
                        onClick = onReload,
                        modifier = Modifier
                            .size(46.dp)
                            .background(Color(0xCC2A3444), CircleShape)
                            .border(1.dp, Color(0x66FFFFFF), CircleShape)
                            .testTag("reload_button")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reload", tint = Color.White)
                    }

                    // AWP Scope Toggle
                    if (player.activeWeapon.hasScope) {
                        IconButton(
                            onClick = { player.isScoped = !player.isScoped },
                            modifier = Modifier
                                .size(46.dp)
                                .background(if (player.isScoped) Color(0xFF00E676) else Color(0xCC2A3444), CircleShape)
                                .border(1.dp, Color(0x66FFFFFF), CircleShape)
                        ) {
                            Icon(Icons.Default.ZoomIn, contentDescription = "Scope", tint = if (player.isScoped) Color.Black else Color.White)
                        }
                    }

                    // Plant or Defuse action button
                    if (engine.isAtBombSite(player.x, player.y) || engine.isNearPlantedBomb(player.x, player.y)) {
                        IconButton(
                            onClick = onPlantOrDefuse,
                            modifier = Modifier
                                .size(46.dp)
                                .background(Color(0xFFD32F2F), CircleShape)
                                .border(2.dp, Color(0xFFFFC107), CircleShape)
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = "Bomb Action", tint = Color.White)
                        }
                    }
                }

                // PRIMARY FIRE BUTTON
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .background(
                            brush = androidx.compose.ui.graphics.Brush.radialGradient(listOf(Color(0xFFFF7043), Color(0xFFD84315))),
                            shape = CircleShape
                        )
                        .border(3.dp, Color(0xFFFFCC80), CircleShape)
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onPress = {
                                    onFireStateChange(true)
                                    tryAwaitRelease()
                                    onFireStateChange(false)
                                }
                            )
                        }
                        .testTag("fire_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.GpsFixed,
                        contentDescription = "Fire",
                        tint = Color.White,
                        modifier = Modifier.size(38.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun InGameBuyMenuDialog(
    player: PlayerActor,
    onBuyItem: (Int, () -> Unit) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF141A23),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("BUY MENU", color = Color(0xFFFF9800), fontWeight = FontWeight.Black, fontSize = 18.sp)
                Text("CASH: $${player.money}", color = Color(0xFF4CAF50), fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // RIFLES
                Text("RIFLES", color = Color(0xFF90A4AE), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                val ak = GameCatalog.WEAPONS.first { it.id == "ak47" }
                val m4 = GameCatalog.WEAPONS.first { it.id == "m4a4" }
                val awp = GameCatalog.WEAPONS.first { it.id == "awp" }

                BuyOptionRow(ak.name, "$${ak.cost}", player.money >= ak.cost) {
                    onBuyItem(ak.cost) {
                        player.activeWeapon = ak
                        player.ammoInMag = ak.magSize
                    }
                }
                BuyOptionRow(m4.name, "$${m4.cost}", player.money >= m4.cost) {
                    onBuyItem(m4.cost) {
                        player.activeWeapon = m4
                        player.ammoInMag = m4.magSize
                    }
                }
                BuyOptionRow(awp.name, "$${awp.cost}", player.money >= awp.cost) {
                    onBuyItem(awp.cost) {
                        player.activeWeapon = awp
                        player.ammoInMag = awp.magSize
                    }
                }

                // PISTOLS
                Text("PISTOLS", color = Color(0xFF90A4AE), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                val deagle = GameCatalog.WEAPONS.first { it.id == "deagle" }
                BuyOptionRow(deagle.name, "$${deagle.cost}", player.money >= deagle.cost) {
                    onBuyItem(deagle.cost) {
                        player.activeWeapon = deagle
                        player.ammoInMag = deagle.magSize
                    }
                }

                // GEAR & UTILITY
                Text("GEAR & GRENADES", color = Color(0xFF90A4AE), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                BuyOptionRow("Kevlar + Helmet", "$1,000", player.money >= 1000 && (!player.hasHelmet || player.armor < 100)) {
                    onBuyItem(1000) {
                        player.armor = 100
                        player.hasHelmet = true
                    }
                }
                if (player.isCT) {
                    BuyOptionRow("Defuse Kit", "$400", player.money >= 400 && !player.hasDefuseKit) {
                        onBuyItem(400) {
                            player.hasDefuseKit = true
                        }
                    }
                }
                BuyOptionRow("Smoke Grenade", "$300", player.money >= 300 && player.smokeCount < 1) {
                    onBuyItem(300) { player.smokeCount++ }
                }
                BuyOptionRow("Flashbang (x2 Max)", "$200", player.money >= 200 && player.flashCount < 2) {
                    onBuyItem(200) { player.flashCount++ }
                }
                BuyOptionRow("HE Grenade", "$300", player.money >= 300 && player.heCount < 1) {
                    onBuyItem(300) { player.heCount++ }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9800))
            ) {
                Text("CLOSE", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
private fun BuyOptionRow(name: String, price: String, canAfford: Boolean, onBuy: () -> Unit) {
    Surface(
        color = if (canAfford) Color(0xFF1E2530) else Color(0xFF161B22),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = canAfford) { onBuy() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(name, color = if (canAfford) Color.White else Color(0xFF78909C), fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(price, color = if (canAfford) Color(0xFF4CAF50) else Color(0xFF78909C), fontSize = 13.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun VirtualJoystick(
    onMove: (Float, Float) -> Unit
) {
    var thumbOffsetX by remember { mutableFloatStateOf(0f) }
    var thumbOffsetY by remember { mutableFloatStateOf(0f) }
    val maxRadius = 45f

    Box(
        modifier = Modifier
            .size(100.dp)
            .background(Color(0x55000000), CircleShape)
            .border(2.dp, Color(0x44FFFFFF), CircleShape)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDrag = { change, dragAmount ->
                        change.consume()
                        val newX = thumbOffsetX + dragAmount.x
                        val newY = thumbOffsetY + dragAmount.y
                        val dist = hypot(newX, newY)
                        if (dist <= maxRadius) {
                            thumbOffsetX = newX
                            thumbOffsetY = newY
                        } else {
                            thumbOffsetX = (newX / dist) * maxRadius
                            thumbOffsetY = (newY / dist) * maxRadius
                        }
                        onMove(thumbOffsetX / maxRadius, thumbOffsetY / maxRadius)
                    },
                    onDragEnd = {
                        thumbOffsetX = 0f
                        thumbOffsetY = 0f
                        onMove(0f, 0f)
                    },
                    onDragCancel = {
                        thumbOffsetX = 0f
                        thumbOffsetY = 0f
                        onMove(0f, 0f)
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .offset { IntOffset(thumbOffsetX.roundToInt(), thumbOffsetY.roundToInt()) }
                .size(40.dp)
                .background(Color(0xFFFF9800), CircleShape)
                .border(2.dp, Color.White, CircleShape)
        )
    }
}

@Composable
private fun MatchConclusionDialog(
    won: Boolean,
    ctScore: Int,
    tScore: Int,
    onDismiss: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000)),
        contentAlignment = Alignment.Center
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E2530)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .padding(24.dp)
                .fillMaxWidth()
                .border(2.dp, if (won) Color(0xFFFF9800) else Color(0xFFD32F2F), RoundedCornerShape(16.dp))
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (won) "VICTORY!" else "DEFEAT",
                    color = if (won) Color(0xFFFF9800) else Color(0xFFEF5350),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "FINAL SCORE: CT $ctScore - $tScore T",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                Surface(
                    color = Color(0xFF263238),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("MMR Rating Change", color = Color(0xFF90A4AE), fontSize = 13.sp)
                            Text(if (won) "+25 Elo" else "-15 Elo", color = if (won) Color(0xFF4CAF50) else Color(0xFFEF5350), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Coins Earned", color = Color(0xFF90A4AE), fontSize = 13.sp)
                            Text(if (won) "+150 Coins" else "+50 Coins", color = Color(0xFFFFD54F), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9800)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("match_continue_button")
                ) {
                    Text("RETURN TO LOBBY", color = Color.Black, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}
