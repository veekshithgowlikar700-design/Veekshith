package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.GameCatalog
import com.example.data.model.MapBlueprint
import com.example.ui.ScreenState
import com.example.ui.StrikeZoneViewModel

@Composable
fun LobbyScreen(
    viewModel: StrikeZoneViewModel,
    onSignOut: () -> Unit
) {
    val userProfile by viewModel.userProfile.collectAsState()
    val isSearching by viewModel.isSearchingMatch.collectAsState()
    val statusMsg by viewModel.statusMessage.collectAsState()
    val selectedMap by viewModel.selectedMap.collectAsState()

    val rankTierInfo = GameCatalog.getTierForPoints(userProfile?.rankPoints ?: 1000L)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F1318))
    ) {
        // TOP HEADER: Profile, Rank, Coins
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF1E2530), Color(0xFF141921))
                    )
                )
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                // User & Rank
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .background(Color(0xFF2A3444), CircleShape)
                            .border(2.dp, Color(rankTierInfo.colorHex), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Person,
                            contentDescription = "Avatar",
                            tint = Color(0xFFFF9800),
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = userProfile?.displayName ?: "Striker",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Shield,
                                contentDescription = null,
                                tint = Color(rankTierInfo.colorHex),
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${rankTierInfo.name} (${userProfile?.rankPoints ?: 1000} MMR)",
                                color = Color(rankTierInfo.colorHex),
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                // Coins & Signout
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = Color(0xFF263238),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .clickable { viewModel.navigateTo(ScreenState.MARKETPLACE) }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                Icons.Default.MonetizationOn,
                                contentDescription = "Coins",
                                tint = Color(0xFFFFD54F),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${userProfile?.coins ?: 0}",
                                color = Color(0xFFFFD54F),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }

                    Button(
                        onClick = onSignOut,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF2A3444)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Text("Exit", color = Color(0xFFECEFF1), fontSize = 12.sp)
                    }
                }
            }
        }

        // Status banner if any
        statusMsg?.let { msg ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF2E3B4E))
                    .padding(8.dp)
            ) {
                Text(
                    text = msg,
                    color = Color(0xFFFFCC80),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // MATCHMAKING HERO BANNER
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1B222C)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0x33FF9800), RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text(
                                    text = "RANKED COMPETITIVE",
                                    color = Color(0xFFFF9800),
                                    fontWeight = FontWeight.Black,
                                    fontSize = 18.sp,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "1v1 Aim & Defusal League Matchmaking",
                                    color = Color(0xFF90A4AE),
                                    fontSize = 12.sp
                                )
                            }
                            Icon(
                                Icons.Default.SportsEsports,
                                contentDescription = null,
                                tint = Color(0xFFFF9800),
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        if (isSearching) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF263238), RoundedCornerShape(10.dp))
                                    .padding(12.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = Color(0xFFFF9800),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "QUEUING FOR OPPONENT...",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Button(
                                    onClick = { viewModel.cancelMatchmaking() },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text("Cancel", fontSize = 11.sp)
                                }
                            }
                        } else {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = { viewModel.startRankedMatchmaking() },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9800)),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("ranked_matchmaking_button")
                                ) {
                                    Icon(Icons.Default.Bolt, contentDescription = null, tint = Color.Black)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("FIND RANKED 1v1", color = Color.Black, fontWeight = FontWeight.Black)
                                }

                                Button(
                                    onClick = { viewModel.start1v1Match(selectedMap) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2A3444)),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("quick_duel_button")
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("1v1 AIM DUEL", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // MAP SELECTOR
            item {
                Text(
                    text = "SELECT MAP (ACTIVE: ${selectedMap.name.uppercase()})",
                    color = Color(0xFFB0BEC5),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(GameCatalog.PRELOADED_MAPS) { map ->
                        MapCardItem(
                            map = map,
                            isSelected = map.id == selectedMap.id,
                            onSelect = { viewModel.selectMap(map) },
                            onPractice = { viewModel.startPracticeMatch(map) }
                        )
                    }
                }
            }

            // CAREER STATS SUMMARY
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatCard("K/D RATIO", String.format("%.2f", (userProfile?.kills ?: 0L).toFloat() / (userProfile?.deaths?.coerceAtLeast(1L) ?: 1L)), Modifier.weight(1f))
                    StatCard("HEADSHOTS", "${userProfile?.headshots ?: 0}", Modifier.weight(1f))
                    StatCard("CAREER WINS", "${userProfile?.wins ?: 0}", Modifier.weight(1f))
                }
            }

            // FEATURE HUBS GRID
            item {
                Text(
                    text = "OPERATIONS & COMMUNITY",
                    color = Color(0xFFB0BEC5),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FeatureHubCard(
                            title = "Skin Marketplace",
                            desc = "Buy & sell weapons",
                            icon = Icons.Default.ShoppingBag,
                            color = Color(0xFF4CAF50),
                            modifier = Modifier.weight(1f),
                            testTag = "nav_marketplace_button",
                            onClick = { viewModel.navigateTo(ScreenState.MARKETPLACE) }
                        )
                        FeatureHubCard(
                            title = "Case Opening",
                            desc = "Unbox Rare Knives",
                            icon = Icons.Default.AutoAwesome,
                            color = Color(0xFFE91E63),
                            modifier = Modifier.weight(1f),
                            testTag = "nav_cases_button",
                            onClick = { viewModel.navigateTo(ScreenState.CASE_OPENING) }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FeatureHubCard(
                            title = "Map Editor",
                            desc = "Build custom layouts",
                            icon = Icons.Default.Handyman,
                            color = Color(0xFF29B6F6),
                            modifier = Modifier.weight(1f),
                            testTag = "nav_editor_button",
                            onClick = { viewModel.navigateTo(ScreenState.MAP_EDITOR) }
                        )
                        FeatureHubCard(
                            title = "Community Maps",
                            desc = "Play creator arenas",
                            icon = Icons.Default.Map,
                            color = Color(0xFFAB47BC),
                            modifier = Modifier.weight(1f),
                            testTag = "nav_community_maps_button",
                            onClick = { viewModel.navigateTo(ScreenState.COMMUNITY_MAPS) }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FeatureHubCard(
                            title = "Ranked Leagues",
                            desc = "Global MMR Ladder",
                            icon = Icons.Default.EmojiEvents,
                            color = Color(0xFFFF9800),
                            modifier = Modifier.weight(1f),
                            testTag = "nav_ranked_button",
                            onClick = { viewModel.navigateTo(ScreenState.RANKED_LEAGUES) }
                        )
                        FeatureHubCard(
                            title = "Inventory",
                            desc = "Equip owned skins",
                            icon = Icons.Default.Shield,
                            color = Color(0xFF26A69A),
                            modifier = Modifier.weight(1f),
                            testTag = "nav_inventory_button",
                            onClick = { viewModel.navigateTo(ScreenState.INVENTORY) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MapCardItem(
    map: MapBlueprint,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onPractice: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) Color(0xFF263238) else Color(0xFF171D25)
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .width(180.dp)
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) Color(0xFFFF9800) else Color(0xFF2A3444),
                shape = RoundedCornerShape(12.dp)
            )
            .clickable { onSelect() }
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = map.name,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) Color(0xFFFF9800) else Color.White,
                fontSize = 15.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = map.description,
                color = Color(0xFF90A4AE),
                fontSize = 11.sp,
                maxLines = 2
            )
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = onPractice,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2A3444)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(30.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
            ) {
                Text("WARMUP VS BOTS", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF171D25)),
        shape = RoundedCornerShape(10.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = title, color = Color(0xFF78909C), fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun FeatureHubCard(
    title: String,
    desc: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF171D25)),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
            .clickable { onClick() }
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(color.copy(alpha = 0.2f), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(text = title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(text = desc, color = Color(0xFF78909C), fontSize = 11.sp)
            }
        }
    }
}
