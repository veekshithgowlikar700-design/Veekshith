package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val TacticalOrange = Color(0xFFFF9800)
val TacticalAmber = Color(0xFFFFB74D)
val TacticalDark = Color(0xFF0F1318)
val TacticalSurface = Color(0xFF171D26)
val TacticalBorder = Color(0xFF2B3545)
val TacticalCyan = Color(0xFF00E5FF)
val TacticalRed = Color(0xFFF44336)
val TacticalGreen = Color(0xFF4CAF50)
