package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.assertThrows
import org.junit.Test

class StrikeZoneRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun getOrCreateProfile_validUser_createsProfileAndStarterInventory() {
        runBlocking {
            signInTestUser(ALICE_EMAIL)
            val repository = StrikeZoneRepository(firestore, auth)

            val profile = withTimeout(DEFAULT_TIMEOUT_MS) {
                repository.getOrCreateProfile("AliceStrike", ALICE_EMAIL, "")
            }
            assertEquals("AliceStrike", profile.displayName)
            assertTrue(profile.coins > 0L)

            val inventory = withTimeout(DEFAULT_TIMEOUT_MS) {
                repository.observeInventory().first()
            }
            assertTrue(inventory.isNotEmpty())
        }
    }

    @Test
    fun joinMatchmakingQueue_authenticated_createsQueueTicket() {
        runBlocking {
            signInTestUser(ALICE_EMAIL)
            val repository = StrikeZoneRepository(firestore, auth)

            val ticketId = withTimeout(DEFAULT_TIMEOUT_MS) {
                repository.joinMatchmakingQueue("AliceStrike", "Silver Elite Master", 1200L, "1v1")
            }
            assertTrue(ticketId.isNotEmpty())

            repository.cancelQueue()
        }
    }

    @Test
    fun publishCommunityMap_authenticated_createsCommunityMap() {
        runBlocking {
            signInTestUser(ALICE_EMAIL)
            val repository = StrikeZoneRepository(firestore, auth)

            val mapId = withTimeout(DEFAULT_TIMEOUT_MS) {
                repository.publishCommunityMap(
                    title = "Dust Mini",
                    description = "Tactical close-quarters duel arena",
                    gridData = "{\"tiles\":[]}",
                    width = 16L,
                    height = 16L
                )
            }
            assertTrue(mapId.isNotEmpty())
        }
    }

    @Test
    fun observeUserProfile_unauthenticatedUser_failsWithIllegalStateException() {
        auth.signOut()
        val repository = StrikeZoneRepository(firestore, auth)

        assertThrows(IllegalStateException::class.java) {
            runBlocking {
                withTimeout(DEFAULT_TIMEOUT_MS) {
                    repository.observeUserProfile().first()
                }
            }
        }
    }

    private companion object {
        const val ALICE_EMAIL = "alice_gamer@test.com"
        const val DEFAULT_TIMEOUT_MS = 6000L
    }
}
